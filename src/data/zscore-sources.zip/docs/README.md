# Documentation

**Liens officiels (novembre 2026) :** [application Z-score Niger](https://zscore.tilniger.com/) · [Tout Informatique Lazaret](https://tilniger.com/) · [contact@tilniger.com](mailto:contact@tilniger.com). Les anciennes URL d'hébergement et adresses de Badge Access ne sont plus les contacts de Z-score.

Les statuts ci-dessous distinguent l’état actuel des études et résultats datés. Un ancien nombre de tests ne prouve pas une réexécution sur le checkout courant.

| Statut | Documents | Portée |
|---|---|---|
| CURRENT | [Méthode](references/METHODE.md), guides, format de sauvegarde, PB/orientation, interopérabilité et distribution GPL | Comportement, limites et droits courants |
| CURRENT | [Composants et releases](maintenance/COMPOSANTS_ET_RELEASES.md), [validation manuelle](maintenance/VALIDATION_MANUELLE.md), vérification publique | Procédures ; une matrice vide n’est pas un essai réussi |
| CURRENT, confirmations à obtenir | Références nationales et références complémentaires | Distinguer références actives, recherchées et protocole à authentifier |
| CURRENT | [PCIMA Niger 2023](references/PCIMA_NIGER_2023.md) | Couverture documentaire complète, adaptation pédiatrique limitée, ambiguïtés et exclusions explicites |
| CURRENT | [CDC](references/CDC.md) | Profil américain explicite dans les sources courantes ; portée, méthodes et vérifications distinctes des essais navigateur/terrain |
| CURRENT | [INTERGROWTH](references/INTERGROWTH.md) | Profil postnatal explicite ; PMA distinct, méthodes, stockage/export et limites |
| HISTORICAL | Mises à jour, préparation initiale de publication, sélection Git initiale | États et décisions datés ; CONTRIBUTING décrit la procédure actuelle |
| HISTORICAL / SUPERSEDED | Audit des droits et options propriétaires de DROITS_ET_LICENCES | COPYING, NOTICE et distribution GPL font foi pour la licence courante |
| MAINTAINER ONLY | `docs/projet/`, `.local/`, tests privés | Plans, entretiens, audits et terrain ; exclus de la distribution publique |

[Contribuer](../CONTRIBUTING.md) · [Sécurité](../SECURITY.md).

- [Guide utilisateur](guides/GUIDE_UTILISATEUR.md)
- [Guide administrateur](guides/GUIDE_ADMINISTRATEUR.md)
- [Format des sauvegardes](references/FORMAT_SAUVEGARDE.md)
- [Droits et licences](references/DROITS_ET_LICENCES.md)
- [Références nationales](references/REFERENCES_NATIONALES.md)
- [Mises à jour](maintenance/MISES_A_JOUR.md)
- [Préparation de la publication](maintenance/PREPARATION_PUBLICATION.md)
- [Périmètre Git](maintenance/SYNCHRONISATION_GIT.md)

Le dossier projet contient le plan, les états de validation et l’ancien README complet ; il reste local et exclu du dépôt. Les audits historiques sont préservés, octets inchangés, sous .local/audit/historique. Les chemins anciens dans ces preuves décrivent l’organisation au moment de leur création.

- [PB et orientation](references/EVALUATION_NUTRITIONNELLE.md)
- [Rapports agrégés / DHIS2](references/INTEROPERABILITE.md)

- [Périmètre et vérifications reproductibles](guides/PERIMETRE_ET_VERIFICATION.md)
- [Référentiels complémentaires identifiés](references/REFERENTIELS_COMPLEMENTAIRES.md)

- [Présentation publique, captures et réglages GitHub appliqués](maintenance/PRESENTATION_PUBLIQUE.md)

Cadres nationaux : [PCIMA Niger 2025](references/PCIMA_NIGER_2025.md), [2023 conservé](references/PCIMA_NIGER_2023.md), [provenance des copies](references/PCIMA_SOURCES.json). Guides et tests publics ; documents PDF et preuves privés.
