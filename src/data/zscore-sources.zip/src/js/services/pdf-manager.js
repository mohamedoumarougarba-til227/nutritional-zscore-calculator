/** Local reports of stored results. Never recalculate, write history or parse patient text as HTML. */
const SupplementaryPDF=typeof module!=='undefined'&&module.exports?require('./supplementary-growth.js').SupplementaryGrowth:SupplementaryGrowth;
const CentilePDF=typeof module!=='undefined'&&module.exports?require('./percentile-display.js').PercentileDisplay:globalThis.PercentileDisplay;
const NutritionPDF=typeof module!=='undefined'&&module.exports?require('./nutrition-assessment.js').NutritionAssessment:globalThis.NutritionAssessment;
class PDFManager {
    static fontPaths = ['vendor/pdf/Amiri-Regular.ttf', 'vendor/pdf/Amiri-Bold.ttf'];
    static async loadFonts(fetcher = fetch, pins = JSON.parse(document.querySelector('meta[name="zscore-data-integrity"]')?.content || '{}')) {
        const responses = await Promise.all(this.fontPaths.map(path => fetcher(path)));
        const bytes = await Promise.all(responses.map(async (response, i) => {
            if (!response.ok) throw new Error('pdfUnavailable');
            const value = await response.arrayBuffer(), expected = pins[this.fontPaths[i]];
            if (!/^[a-f0-9]{64}$/.test(expected || '') || value.byteLength > 1_000_000 || await ReleaseGuard.digest(value) !== expected) throw new Error('pdfUnavailable');
            return value;
        }));
        return bytes.map(buffer => {
            let text = ''; const data = new Uint8Array(buffer);
            for (let i = 0; i < data.length; i += 8192) text += String.fromCharCode(...data.subarray(i, i + 8192));
            return btoa(text);
        });
    }
    static clean(value) {
        const text = String(value ?? '');
        if (text.length > 6000) throw new Error('pdfInvalid');
        return text.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F\u200E\u200F\u202A-\u202E\u2066-\u2069]/g, '').replace(/\r\n?/g, '\n');
    }
    static model(entries, { language = 'fr', translations, stale = false } = {}) {
        if (!Array.isArray(entries) || !entries.length || entries.length > 5000 || !['fr', 'en', 'ar'].includes(language) || !translations?.[language]) throw new Error('pdfInvalid');
        const t = key => {const own=table=>table&&Object.hasOwn(table,key)&&typeof table[key]==='string'?table[key]:'';return this.clean(own(translations[language])||own(translations.fr)||key);};
        const number = (value, digits) => typeof value === 'number' && Number.isFinite(value) ? value.toFixed(digits) : t('unknown');
        const indicators = ['weightForAge','heightForAge','weightForHeight','bmiForAge'].filter(key=>entries.some(e=>(e.result?.applicableIndicators||['weightForAge','heightForAge','weightForHeight','bmiForAge']).includes(key)));
        const provenances=[];
        const rows = entries.map((entry, i) => {
            if (!entry?.child || typeof entry.child !== 'object') throw new Error('pdfInvalid');
            const {child: c, result: r} = entry;
            if(r&&r.schemaVersion!==4)throw new Error('importVersion');
            const field = (label, value) => t(label) + ' : ' + this.clean(value === undefined || value === '' ? t('unknown') : value);
            const identity = [field('name', c.name), field('caseId', c.caseId), field('measurementDate', c.measurementDate)];
            const age = [field('ageDays', number(c.ageDays, 0)), field('ageMode', t(c.ageMode || 'unknown'))];
            if (c.ageMode === 'months') age.push(field('ageYears', c.ageYears), field('ageMonths', c.ageMonths), t('approximateAge'));
            if(c.ageMode==='totalMonths')age.push(field('ageTotalMonths',c.totalAgeMonths),t('approximateAge'));
            if (c.ageMode === 'dates') age.push(field('birthDate', c.birthDate));
            const measures = [...age, field('weight', number(c.weight, 0)), field('height', number(c.height, 1)),
                field('gender', t(c.gender === 'M' ? 'male' : c.gender === 'F' ? 'female' : 'unknown')),
                field('position', t(c.position === 'L' ? 'lying' : c.position === 'H' ? 'standing' : 'unknown')),
                field('oedema', t(c.oedema === 'y' ? 'yes' : c.oedema === 'n' ? 'no' : 'unknown'))];
            if (typeof r?.correctedHeight === 'number') measures.push(field('adjustedHeight', number(r.correctedHeight, 1) + ' ' + t('unitCm')));
            if (r?.schemaVersion===4 && typeof r.bmi==='number' && Number.isFinite(r.bmi)) measures.push(field('bmi',number(r.bmi,2)+' kg/m²'));
            const notes = [];
            for(const key of SupplementaryPDF.fields)if(SupplementaryPDF.present(c[key]))measures.push(field(key,number(c[key],1)));
            if(r?.additionalGrowth){notes.push(t('additionalResults')+' · '+r.additionalGrowth.referenceVersion);for(const [key,v] of Object.entries(r.additionalGrowth.indicators)){const centile=CentilePDF.text(v);const score=Number.isFinite(v.zscore)?'Z = '+number(v.zscore,2)+(centile===null?'':' | P '+centile)+' | '+t(v.classification||'intergrowthDescriptive'):t(v.error);notes.push(t(key)+' : '+number(v.measure,1)+' '+v.unit+' | '+score+(v.flagged?' | '+t('flagged'):''));}}
            if(c.muac!==undefined&&c.muac!=='')measures.push(field('muac',number(c.muac,1)+' mm'));
            if(r?.nutrition)notes.push(t(r.nutrition.category),...(r.nutrition.criteria||[]).map(t),t(r.nutrition.muac),t(r.nutrition.orientation),...r.nutrition.reasons.map(t),t('clinicalReference')+' : '+r.nutrition.reference+' v'+r.nutrition.version,...(r.nutrition.missing.length?[t('assessmentMissing')+' : '+r.nutrition.missing.map(t).join(', ')]:[]));
            if(NutritionPDF.isNational(r?.nutrition)){
                notes.push(t(NutritionPDF.helpKey(r.nutrition)));
                for(const key of NutritionPDF.inputFields.filter(k=>!['muac','careProtocol'].includes(k))) if(c[key]) measures.push(field(key,t(NutritionPDF.observationLabel(key,c[key],NutritionPDF.is2025(r.nutrition)?'2025':true))));
            }
            let provenance=null;
            if (!r) notes.push(t('pdfUncalculated'));
            else {
                if (r.schemaVersion===4) notes.push(t(r.referenceFamily==='INTERGROWTH2015'?'intergrowthDescriptive':r.referenceFamily==='CDC2000'?'cdcCoverage':'bmiReportHelp'));
                if(r.intergrowthContext){
                    const a=r.intergrowthContext.age;measures.push(field('growthProfile',t('profileINTERGROWTH')),field('postmenstrualDays',number(a.postmenstrualDays,0)),field('birthGestationDays',number(a.birthGestationDays,0)));
                    notes.push(t('intergrowthNoScreening'),field('postmenstrualDays',number(a.postmenstrualDays,0))+' | '+field('birthGestationDays',number(a.birthGestationDays,0)));
                    for(const [key,v] of Object.entries(r.intergrowthContext.scores))if(v.method)notes.push(t(key==='lengthForAge'?'heightForAge':key)+' | '+v.method);
                }else if(r.profileContext){
                    measures.push(field('growthProfile',t('profileUS')),field('reportedAgeMonths',number(r.profileContext.reportedAgeInMonths,3)),field('calculationAgeMonths',number(r.ageInMonths,3)),field('agePrecision',t(r.profileContext.agePrecision)));
                    notes.push(t('profileUS')+' | '+t('reportedAgeMonths')+' : '+number(r.profileContext.reportedAgeInMonths,3)+' | '+t('calculationAgeMonths')+' : '+number(r.ageInMonths,3)+' | '+t(r.profileContext.agePrecision));
                }
                if(r.referenceFamily==='CDC2000'){
                    notes.push(t('cdcInterpretation'));
                    for(const key of ['weightForAge','heightForAge','bmiForAge'])if(r[key]?.method)notes.push(t(key)+' | '+r[key].method+' | '+t('modifiedZscore')+' : '+number(r[key].modifiedZscore,3));
                    if(Number.isFinite(r.bmiForAge?.percentOfP95))notes.push(t('percentOfP95')+' : '+number(r.bmiForAge.percentOfP95,1)+' %');
                }
                if(r.schemaVersion===4&&r.referenceFamily==='WHO2007')notes.push(t('coverage2007'));
                if (r.imported) notes.push(t('importedResult'));
                notes.push(...(Array.isArray(r.warnings) ? r.warnings.map(t) : []));
                const value=[this.clean(r.referenceVersion || 'unknown'),this.clean(r.engineVersion || t('unknown'))];
                let p=provenances.findIndex(pair=>pair[0]===value[0]&&pair[1]===value[1]);
                if(p<0){p=provenances.length;provenances.push(value);}provenance='R'+(p+1);
            }
            const scores = indicators.map(key => {
                const v = r?.[key], valid = typeof v?.zscore === 'number' && Number.isFinite(v.zscore);
                const lines = [valid ? 'Z = ' + v.zscore.toFixed(2) : t('notCalculated')];
                if (valid) lines.push(t(v.classification || (r.referenceFamily==='INTERGROWTH2015'?'intergrowthDescriptive':'unknown')));
                if (v?.flagged) lines.push(t('flagged'));
                if (v?.error) lines.push(t(v.error));
                return lines.join('\n');
            });
            const percentiles=indicators.map(key=>{
                const v=r?.[key];
                if(r?.schemaVersion!==4||r.percentileVersion!==1||!Number.isFinite(v?.zscore))return '';
                return 'P '+(CentilePDF.text(v)??'--');
            });
            const compactMeasures=[...(r?.intergrowthContext?[field('postmenstrualDays',number(r.intergrowthContext.age.postmenstrualDays,0))]:[]),field('ageDays',number(c.ageDays,0)),field('weight',number(c.weight,0)),field('height',number(c.height,1)),
                t(c.gender==='M'?'male':c.gender==='F'?'female':'unknown')+' | '+t(c.position==='L'?'lying':c.position==='H'?'standing':'unknown'),
                t('pdfOedema')+' : '+t(c.oedema==='y'?'yes':c.oedema==='n'?'no':'unknown')];
            if(c.ageMode==='totalMonths')compactMeasures.push(field('ageTotalMonths',c.totalAgeMonths),t('approximateAge'));
            if(c.ageMode==='months')compactMeasures.push(field('ageYears',c.ageYears)+' | '+field('ageMonths',c.ageMonths),t('approximateAge'));
            if(c.ageMode==='dates')compactMeasures.push(field('birthDate',c.birthDate));
            if(typeof r?.correctedHeight==='number')compactMeasures.push(field('adjustedHeight',number(r.correctedHeight,1)+' '+t('unitCm')));
            if(r?.schemaVersion===4 && typeof r.bmi==='number' && Number.isFinite(r.bmi))compactMeasures.push(field('bmi',number(r.bmi,2)+' kg/m²'));
            const heightPair=number(c.height,1)+(typeof r?.correctedHeight==='number'?' / '+number(r.correctedHeight,1):'');
            const briefMeasures=[number(c.weight,0)+' g | '+heightPair+' cm',number(c.ageDays,0)+' '+t('pdfDaysUnit')+' ('+t(c.ageMode||'unknown')+') | '+this.clean(c.gender||t('unknown'))+' | '+this.clean(c.position||t('unknown')),t('pdfOedema')+' : '+t(c.oedema==='y'?'yes':c.oedema==='n'?'no':'unknown')];
            if(r?.intergrowthContext)briefMeasures.unshift(field('postmenstrualDays',number(r.intergrowthContext.age.postmenstrualDays,0)));
            if(c.ageMode==='totalMonths')briefMeasures.push(field('ageTotalMonths',c.totalAgeMonths),t('approximateAge'));
            if(c.ageMode==='months')briefMeasures.push(field('ageYears',c.ageYears)+' | '+field('ageMonths',c.ageMonths),t('approximateAge'));
            if(c.ageMode==='dates')briefMeasures.push(field('birthDate',c.birthDate));
            if(r?.schemaVersion===4 && typeof r.bmi==='number' && Number.isFinite(r.bmi))briefMeasures.push(field('bmi',number(r.bmi,2)+' kg/m²'));
            if(c.muac!==undefined&&c.muac!==''){const pb=field('muac',number(c.muac,1)+' mm');compactMeasures.push(pb);briefMeasures.push(pb);}
            return {index:i+1,identity,measures,compactMeasures,briefMeasures,briefIdentity:[this.clean(c.name||t('unknown')),this.clean(c.caseId||t('unknown'))],measurementDate:this.clean(c.measurementDate||t('unknown')),scores,percentiles,notes:[...new Set(notes.filter(Boolean))],provenance,calculatedAt:this.clean(r?.calculatedAt||t('unknown'))};
        });
        const hasPercentiles=rows.some(row=>row.percentiles.some(Boolean))||entries.some(entry=>Object.values(entry.result?.additionalGrowth?.indicators||{}).some(value=>CentilePDF.text(value)!==null));
        return {language, t, indicators, rows, stale, provenances,hasPercentiles,keys:['pdfNumber','pdfIdentity','pdfMeasures',...indicators,'pdfNotes']};
    }
    static compact(model) {
        const categories=[],notes=[];
        const code=(values,text,prefix)=>{if(!text)return '';let index=values.indexOf(text);if(index<0){index=values.length;values.push(text);}return prefix+(index+1);};
        const body=model.rows.map(row=>[String(row.index),row.briefIdentity.join('\n'),row.measurementDate,row.briefMeasures.join('\n'),
            ...row.scores.map((score,i)=>{const lines=score.split('\n'),numeric=lines[0].startsWith('Z = ');return (numeric?lines[0].slice(4):'--')+'\n'+code(categories,(numeric?lines.slice(1):lines).join('\n'),'C')+(row.percentiles[i]?'\n'+row.percentiles[i]:'');}),
            [row.provenance||'',row.calculatedAt,code(notes,row.notes.join('\n'),'N')].filter(Boolean).join('\n')]);
        return {body,legend:[...categories.map((text,i)=>['C'+(i+1),text]),...notes.map((text,i)=>['N'+(i+1),text])]};
    }
    static scoreWithPercentile(row,index) {
        const score=row.scores[index],p=row.percentiles[index];
        if(!p)return score;
        const newline=score.indexOf('\n');
        return newline<0?score+' | '+p:score.slice(0,newline)+' | '+p+score.slice(newline);
    }
    // AutoTable 5 marks split remainder rows with index -1 and keeps the original
    // raw row. Its record number remains unambiguous even when other cells are empty.
    static continuedRowIndex(data, rtl = false) {
        if(data?.section!=='body'||data.row?.index!==-1||!Array.isArray(data.row.raw))return null;
        const raw=data.row.raw,index=raw[rtl?raw.length-1:0];
        return typeof index==='string'&&/^[1-9]\d*$/.test(index)?index:null;
    }
    static reportSections = ['pdfSingleReport','pdfGrowthReport','chartTitle','pdfAdditionalGrowth','additionalZscoreTitle'];
    static reportCharts(visits, engines) {
        const chart=typeof module!=='undefined'&&module.exports?require('../components/growth-chart.js').GrowthChart:GrowthChart;
        const entries=visits.filter(e=>/^\d{4}-\d{2}-\d{2}$/.test(e.child.measurementDate))
            .sort((a,b)=>a.child.measurementDate.localeCompare(b.child.measurementDate));
        const sections=Object.fromEntries(this.reportSections.slice(1).map(key=>[key,[]]));
        const references=new Set(entries.flatMap(e=>[e.result?.referenceVersion,e.result?.additionalGrowth?.referenceVersion]).filter(Boolean));
        for(const reference of references){
            const supplementary=key=>Object.hasOwn(SupplementaryPDF.definitions,key);
            const engine=engines.find(candidate=>candidate.data.referenceVersion===reference);
            const relevant=entries.filter(e=>e.result?.referenceVersion===reference||e.result?.additionalGrowth?.referenceVersion===reference);
            const indexes=new Map(entries.map((entry,index)=>[entry,index]));
            const observations=panel=>panel.points.map(point=>({...point,index:indexes.get(relevant[point.index])}));
            const group=(point,key)=>{
                const {child,result}=entries[point.index];
                const positionSensitive=['heightForAge','weightForHeight','bmiForAge'].includes(key);
                return JSON.stringify([child.gender,result?.engineVersion,chart.indicator(result,key)?.method,
                    positionSensitive&&reference.startsWith('WHO-2006-')?child.ageDays<731:null,positionSensitive?child.position:null]);
            };
            const dateCounts=new Map();
            for(const {child} of entries)dateCounts.set(child.measurementDate,(dateCounts.get(child.measurementDate)||0)+1);
            const series=(points,key)=>points.slice(1).map((point,i)=>[points[i],point]).filter(([a,b])=>
                b.index===a.index+1&&b.date>a.date&&b.day>a.day&&dateCounts.get(a.date)===1&&dateCounts.get(b.date)===1&&group(a,key)===group(b,key));
            if(engine){
                const model=chart.referenceModel(relevant,engine);
                for(const panel of model?.panels||[]){
                    if(!panel.points.length)continue;
                    const points=observations(panel).sort((a,b)=>a.index-b.index);
                    sections[supplementary(panel.key)?'pdfAdditionalGrowth':'pdfGrowthReport'].push({...panel,reference,points,lines:series(points,panel.key),growth:true});
                }
            }
            const model=chart.build(entries,reference);
            for(const panel of model.panels){
                const byDate=new Map(panel.points.map(point=>[point.date,point.day]));
                const points=entries.flatMap((entry,index)=>{
                    const indicator=chart.indicator(entry.result,panel.key),date=entry.child.measurementDate;
                    if(!byDate.has(date)||entry.result?.schemaVersion!==4||chart.reference(entry.result,panel.key)!==reference||
                        indicator?.reference!==reference||!Number.isFinite(indicator.zscore)||Math.abs(indicator.zscore)>6||indicator.flagged||indicator.error)return [];
                    return [{index,day:byDate.get(date),date,value:indicator.zscore,imported:!!entry.result.imported}];
                });
                const groups=new Map();
                const distinct=points.some(point=>{
                    const key=group(point,panel.key),firstDate=groups.get(key);
                    if(!firstDate)groups.set(key,point.date);
                    return firstDate&&point.date>firstDate;
                });
                if(!distinct)continue;
                const lines=series(points,panel.key);
                const bounds=points.reduce(({min,max},p)=>({min:Math.min(min,p.value),max:Math.max(max,p.value)}),{min:-3,max:3});
                sections[supplementary(panel.key)?'additionalZscoreTitle':'chartTitle'].push({key:panel.key,reference,points,lines,...bounds,xMin:points[0].day,xMax:points.at(-1).day});
            }
        }
        return {entries,sections};
    }
    static individual(doc, autoTable, model, entry, options, safe, now) {
        const {t,language,rows:[row],indicators}=model,{child,result}=entry;
        const rtl=language==='ar',margin=12,right=198,width=186,bottom=277;
        const font=options.individualFont||'Amiri';
        const labels={fr:{year:'an',years:'ans',month:'mois',vigilance:'Évaluation clinique et vigilance',engine:'Moteur Z-score',calc:'Calcul',notice:'Repères de croissance selon la référence utilisée. Ne remplacent pas une évaluation clinique. Aucun diagnostic ni prescription automatique.'},en:{year:'year',years:'years',month:'months',vigilance:'Clinical assessment and cautions',engine:'Z-score engine',calc:'Calculated',notice:'Growth indicators use the stated reference. They do not replace clinical assessment. No automatic diagnosis or prescription.'},ar:{year:'سنة',years:'سنوات',month:'شهر',vigilance:'التقييم السريري والتنبيهات',engine:'محرك Z',calc:'الحساب',notice:'مؤشرات النمو حسب المرجع المستخدم. لا تحل محل التقييم السريري. لا تشخيص أو وصفة تلقائية.'}}[language];
        const date=value=>language==='fr'&&/^\d{4}-\d{2}-\d{2}$/.test(value||'')?value.slice(8,10)+'/'+value.slice(5,7)+'/'+value.slice(0,4):value;
        const timestamp=value=>/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z$/.test(value||'')?date(value.slice(0,10))+' '+value.slice(11,-1)+' UTC':value;
        const centile=value=>language==='fr'?String(value??'—').replace(/(\d)\.(\d)/g,'$1,$2'):String(value??'—');
        const number=(value,digits=0)=>Number.isFinite(value)?new Intl.NumberFormat(language,{minimumFractionDigits:digits,maximumFractionDigits:digits}).format(value):'—';
        const field=(key,value)=>t(key)+': '+(value||t('unknown'));
        const unit=(value,digits,label)=>Number.isFinite(value)?number(value,digits)+' '+label:'—';
        const place=(value,x,y,{size=10,bold=false,align=rtl?'right':'left',fieldLabel=false}={})=>{
            doc.setFont(font,bold?'bold':'normal').setFontSize(size).setTextColor(24);
            const text=safe(value);
            doc.text(rtl&&fieldLabel?'\u200F'+text+'\u200F':text,x,y,{align});
        };
        let y=23,title,sectionReference='';
        const pages=new Map(),pageReferences=new Map(),at=()=>doc.internal.getCurrentPageInfo().pageNumber;
        const header=()=>{pages.set(at(),title);if(sectionReference)pageReferences.set(at(),sectionReference);};
        const ensure=space=>{if(y+space>bottom){doc.addPage();header();y=sectionReference?26:23;}};
        const line=(value,{size=10,bold=false,indent=0}={})=>{
            doc.setFont(font,bold?'bold':'normal').setFontSize(size);
            const lines=doc.splitTextToSize(safe(value),width-indent*2);
            const step=size*.425;
            for(const item of lines){
                ensure(step);
                // Preserve the directional marks added by safe() around dates.
                doc.setFont(font,bold?'bold':'normal').setFontSize(size).setTextColor(24);
                doc.text(item,rtl?right-indent:margin+indent,y,{align:rtl?'right':'left'});
                y+=step;
            }
        };
        const heading=(label,ordinal='',aside='')=>{
            ensure(16); y+=2.8;
            const lead=rtl?right:margin;
            if(ordinal){place(ordinal,lead,y,{size:9,bold:true});}
            const titleX=lead+(rtl?-8:8)*(ordinal?1:0);
            place(label,titleX,y,{size:11,bold:true});
            if(aside){
                doc.setFont(font,'bold').setFontSize(11);
                const titleWidth=doc.getTextWidth(safe(label))+(ordinal?8:0);
                doc.setFont(font,'normal').setFontSize(8);
                if(titleWidth+doc.getTextWidth(safe(aside))+4<=width)place(aside,rtl?margin:right,y,{size:8,align:rtl?'left':'right'});
                else {y+=4;place(aside,rtl?right:margin,y,{size:8});}
            }
            doc.setDrawColor(155).setLineWidth(.2).line(margin,y+1.5,right,y+1.5);
            y+=6.5;
        };
        // Fixed columns with individually bold values; long names and provenance wrap instead of clipping.
        const fields=(pairs,weights=pairs.map(()=>1),size=10)=>{
            const gap=3,total=weights.reduce((a,b)=>a+b,0),usable=width-gap*(pairs.length-1),step=size*.43;
            let offset=0;
            const cells=pairs.map(([label,value],i)=>{
                const w=usable*weights[i]/total,x=rtl?right-offset:margin+offset;offset+=w+gap;
                const prefix=safe(label+':'),v=safe(value||t('unknown'));
                doc.setFont(font,'normal').setFontSize(size);
                // Base Helvetica can underestimate the width of the French ligature.
                const measuredPrefix=font==='helvetica'?prefix.replace(/Œ/g,'OE').replace(/œ/g,'oe'):prefix;
                const labelWidth=doc.getTextWidth(measuredPrefix)+1.5;
                doc.setFont(font,'bold').setFontSize(size);const valueWidth=doc.getTextWidth(v);
                const inline=labelWidth+valueWidth<=w&&!v.includes('\n');
                const values=inline?[v]:doc.splitTextToSize(v,w);
                doc.setFont(font,'normal');const prefixes=inline?[prefix]:doc.splitTextToSize(prefix,w);
                return {x,prefixes,values,labelWidth,inline,lines:inline?1:prefixes.length+values.length};
            });
            const height=Math.max(...cells.map(c=>c.lines))*step+1;
            ensure(height);
            for(const c of cells){
                const align=rtl?'right':'left';
                c.prefixes.forEach((v,i)=>place(v,c.x,y+i*step,{size,align,fieldLabel:true}));
                const valueX=c.inline?c.x+(rtl?-c.labelWidth:c.labelWidth):c.x;
                c.values.forEach((v,i)=>place(v,valueX,y+(c.inline?0:c.prefixes.length+i)*step,{size,bold:true,align}));
            }
            y+=height;
        };
        const note=(value,kind='info',shaded=false,compact=false)=>{
            const size=9.1,step=3.85,iconSpace=7;
            doc.setFont(font,'normal').setFontSize(size);
            const lines=doc.splitTextToSize(safe(value),width-iconSpace-4);
            const height=Math.max(5.5,lines.length*step+(compact?.95:2.5));
            ensure(height);
            const top=y-3,ix=rtl?right-3.2:margin+3.2;
            if(shaded)doc.setFillColor(247).rect(margin,top,width,height,'F');
            doc.setFillColor(239).roundedRect(ix-2.5,top+.35,5,5,.65,.65,'F');
            doc.setDrawColor(55).setLineWidth(.28).setLineDashPattern([],0);
            const cy=top+2.8;
            if(kind==='warning'){
                doc.triangle(ix,cy-1.8,ix-1.9,cy+1.6,ix+1.9,cy+1.6,'S');
                doc.line(ix,cy-.55,ix,cy+.4);doc.setFillColor(55).circle(ix,cy+1,.13,'F');
            }else if(kind==='bulb'){
                doc.circle(ix,cy-.4,1.25,'S');doc.line(ix-.55,cy+.8,ix+.55,cy+.8);doc.line(ix-.4,cy+1.45,ix+.4,cy+1.45);
            }else{
                doc.circle(ix,cy,1.6,'S');doc.line(ix,cy-.05,ix,cy+.9);doc.setFillColor(55).circle(ix,cy-.75,.13,'F');
            }
            lines.forEach((v,i)=>place(v,rtl?right-iconSpace:margin+iconSpace,y+i*step,{size}));
            y+=height;
        };
        const table=(head,body,highlightLast=false)=>{
            if(!body.length)return;
            ensure(18);
            autoTable(doc,{startY:y-2,theme:'plain',head:[rtl?[...head].reverse():head],
                body:rtl?body.map(r=>[...r].reverse()):body,
                margin:{top:22,bottom:297-bottom,left:margin,right:margin},rowPageBreak:'avoid',
                styles:{font,fontSize:9.7,cellPadding:{top:highlightLast?1.05:.75,right:1.25,bottom:highlightLast?1.05:.75,left:1.25},overflow:'linebreak',textColor:24,halign:rtl?'right':'left',lineWidth:{bottom:.16},lineColor:175},
                headStyles:{fontStyle:'bold',textColor:18,fillColor:false},
                columnStyles:highlightLast?Object.fromEntries(head.map((_,i)=>[rtl?head.length-1-i:i,i===0?{cellWidth:25}:i===1?{cellWidth:15,halign:'center'}:{halign:'center'}])):
                    Object.fromEntries((head.length===4?[70,20,18,78]:[55,28,18,15,70]).map((cellWidth,i)=>[rtl?head.length-1-i:i,{cellWidth,...(i>0&&i<head.length-1?{halign:'center'}:{})}])),
                willDrawPage:()=>{if(!pages.has(at()))header();},
                didParseCell:({cell,row:r,section,column})=>{
                    cell.text=cell.text.map(safe);
                    const index=rtl?head.length-1-column.index:column.index;
                    if(section==='head'&&index>0&&(highlightLast||index<head.length-1))cell.styles.halign='center';
                    if(section==='body'&&(highlightLast?r.index===body.length-1:cell.raw==='—'||/^(?:[<>]\s*)?[−-]?\d[\d\s.,]*(?:\s(?:cm|mm|kg|g|kg\/m²))?$/.test(String(cell.raw))))cell.styles.fontStyle='bold';
                }});
            y=doc.lastAutoTable.finalY+5;
        };
        const selected=new Set(options.sections??[this.reportSections[0]]);
        const chartData=options.charts??{entries:[],sections:{}};
        const active=this.reportSections.filter(key=>selected.has(key)&&(key===this.reportSections[0]||chartData.sections[key]?.length));
        if(!active.length)throw new Error('pdfInvalid');
        title=active[0];header();
        const estimated=['months','totalMonths'].includes(child.ageMode)||child.agePrecision==='completedMonths';
        const ageDays=unit(child.ageDays,0,t('pdfDaysUnit'));
        const years=Number(child.ageYears),months=Number(child.ageMonths),totalMonths=Number(child.totalAgeMonths??child.ageTotalMonths);
        const ageText=child.ageMode==='months'&&child.ageYears!==undefined&&child.ageMonths!==undefined&&Number.isFinite(years)&&Number.isFinite(months)?
            [years?number(years)+' '+(years===1?labels.year:labels.years):'',months||!years?number(months)+' '+labels.month:''].filter(Boolean).join(' ')+' ('+ageDays+')':
            child.ageMode==='totalMonths'&&Number.isFinite(totalMonths)?new Intl.NumberFormat(language,{maximumFractionDigits:3}).format(totalMonths)+' '+labels.month+' ('+ageDays+')':ageDays;
        const identity=()=>{
            fields([[t('pdfNameShort'),child.name?.trim()],[t('pdfCaseShort'),child.caseId?.trim()]],[1,1]);
            fields([[t(estimated?'referenceEstimated':'pdfAgeShort'),ageText],[t('gender'),t(child.gender==='M'?'male':child.gender==='F'?'female':'unknown')],[t('measurementDate'),date(child.measurementDate)]],[1.35,.8,1]);
        };
        if(selected.has(this.reportSections[0])){
            identity();
            if(model.stale)line(t('stale'),{bold:true});
            if(result?.imported)line(t('importedResult'),{bold:true});
            const assessment=result?.nutrition;
            if(assessment){
                const label=t(NutritionPDF.is2025(assessment)?'screeningTitlePcima2025':NutritionPDF.isNational(assessment)?'screeningTitlePcima':'screeningTitle');
                const status=t(assessment.category);
                const details=[...new Set([...(assessment.criteria||[]),...(assessment.reasons||[])])].map(t);
                const orientation=field('pdfOrientation',t(assessment.orientation));
                doc.setFont(font,'bold').setFontSize(11);
                const statusLines=doc.splitTextToSize(safe(status),width-10).length;
                doc.setFont(font,'normal').setFontSize(10);
                const content=[...details,orientation];
                const contentLines=content.reduce((count,value)=>count+doc.splitTextToSize(safe(value),width-10).length,0);
                const boxHeight=8+4.675*statusLines+4.25*contentLines;
                ensure(boxHeight+6);
                const top=y+1;
                doc.setDrawColor(35).setLineWidth(.28).roundedRect(margin,top,width,boxHeight,2,2);
                doc.setFont(font,'bold').setFontSize(10);
                const labelWidth=doc.getTextWidth(safe(label))+4;
                doc.setFillColor(255).rect(rtl?right-5-labelWidth:margin+5,top-1,labelWidth,2,'F');
                place(label,rtl?right-7:margin+7,top+1,{bold:true});
                y=top+6;line(status,{bold:true,size:11,indent:5});
                content.forEach(value=>line(value,{indent:5}));
                y=top+boxHeight+4.5;
            }
            heading(t('pdfMeasures'),'01');
            fields([[t('pdfWeightShort'),unit(child.weight,0,'g')],[t('pdfHeightShort'),unit(child.height,1,'cm')],
                ...(assessment||Number.isFinite(child.muac)?[[t('pdfMuacShort'),Number.isFinite(child.muac)?unit(child.muac,1,'mm'):t('unknown')]]:[]),
                ...(Number.isFinite(result?.bmi)?[[t('bmi'),unit(result.bmi,2,'kg/m²')]]:[])]);
            fields([[t('position'),t(child.position==='L'?'lying':child.position==='H'?'standing':'unknown')],
                [t('pdfOedemaShort'),t(child.oedema==='y'?'yes':child.oedema==='n'?'no':'unknown')],
                ...(Number.isFinite(result?.correctedHeight)&&Math.abs(result.correctedHeight-child.height)>.01?[[t('adjustedHeight'),unit(result.correctedHeight,1,'cm')]]:[])],undefined,9.5);
            const age=result?.intergrowthContext?.age;
            if(age)line([field('postmenstrualDays',number(age.postmenstrualDays)),field('birthGestationDays',number(age.birthGestationDays))].join('  |  '));
            const score=value=>Number.isFinite(value?.zscore)?number(value.zscore,2):'—';
            const interpretation=value=>[value?.classification?t(value.classification):(!value?.error?t(Number.isFinite(value?.zscore)?'intergrowthDescriptive':'notCalculated'):''),value?.error?t(value.error==='oedemaWarning'?'pdfOedemaSuspended':value.error):'',value?.flagged?t('flagged'):''].filter(Boolean).join(' · ');
            if(result){
                heading(t('pdfGrowthIndicators'),'02');
                table([t('pdfIndicator'),'Z','P',t('pdfInterpretation')],indicators.map((key,i)=>[t(key),score(result[key]),centile(row.percentiles[i]?.slice(2)||'—'),interpretation(result[key])]));
            }else line(t('pdfUncalculated'),{bold:true});
            const extra=Object.entries(result?.additionalGrowth?.indicators||{});
            if(extra.length){
                heading(t('additionalResults'),'03');
                table([t('pdfIndicator'),t('pdfMeasureShort'),'Z','P',t('pdfInterpretation')],extra.map(([key,value])=>[t(key),unit(value.measure,1,value.unit),score(value),centile(CentilePDF.text(value)),interpretation(value)]));

            }
            const rawExtra=SupplementaryPDF.fields.filter(key=>SupplementaryPDF.present(child[key])&&
                !extra.some(([indicator])=>SupplementaryPDF.definitions[indicator]?.field===key));
            if(rawExtra.length)line(rawExtra.map(key=>field(key,number(child[key],1))).join('  |  '),{size:9.5});
            const observed=assessment?NutritionPDF.inputFields.filter(key=>!['muac','careProtocol'].includes(key)&&child[key]&&child[key]!=='unknown'&&child[key]!=='u')
                .map(key=>field(key,t(NutritionPDF.observationLabel(key,child[key],NutritionPDF.is2025(assessment)?'2025':NutritionPDF.isNational(assessment))))):[];
            const vigilance=[extra.some(([key])=>key==='armCircumferenceForAge')?t('pdfMuacDistinction'):'',
                assessment?.missing?.length?field('pdfToRecord',assessment.missing.map(t).join(', ')):'',
                observed.join('  |  '),...(result?.warnings||[]).map(t),age?t('intergrowthNoScreening'):'',
                result?.referenceFamily==='CDC2000'?t('cdcInterpretation'):''].filter(Boolean);
            if(vigilance.length){heading(labels.vigilance,'04');for(const value of new Set(vigilance))note(value,'info',true,vigilance.length>=4);}
            if(result){
                heading(t('pdfReferences'),'05',labels.calc+': '+timestamp(row.calculatedAt));
                fields([[t('pdfRefShort'),result.referenceVersion],...(result.additionalGrowth&&result.additionalGrowth.referenceVersion!==result.referenceVersion?[[t('pdfExtraShort'),result.additionalGrowth.referenceVersion]]:[])],undefined,8.5);
                fields([...(assessment?[[t('pdfOrientation'),assessment.reference+' v'+assessment.version]]:[]),[labels.engine,result.engineVersion]],assessment?[1.5,1]:undefined,8.5);
                y+=1.5;
                if(model.hasPercentiles)note(t('pdfCentileShort'),'bulb');
            }
            note(labels.notice,'warning');
        }
        for(const key of active.filter(key=>key!==this.reportSections[0])){
            const panels=chartData.sections[key];
            const panelHeight=62,gap=5;
            const references=[...new Set(panels.map(p=>p.reference))];
            const sharedReference=references.length===1?t('pdfRefShort')+': '+references[0]:'';
            const tableHeight=23+Math.min(8,chartData.entries.length)*5.5;
            const sectionHeight=29+Math.ceil(panels.length/2)*panelHeight+Math.ceil(panels.length/4)*tableHeight;
            const startOnNewPage=title===this.reportSections[0]||
                (key!==active[0]&&y+Math.min(sectionHeight,227)>bottom);
            if(startOnNewPage){doc.addPage();title=key;sectionReference=sharedReference;header();y=sectionReference?26:23;identity();}
            else if(key===active[0]){sectionReference=sharedReference;header();if(sectionReference)y=26;identity();}
            else if(pages.get(at())!==key){heading(t(key));if(sharedReference)line(sharedReference,{size:8.5});}
            title=key;sectionReference=sharedReference;
            const referenceList=()=>{if(references.length>1)for(const [index,ref] of references.entries())line('R'+(index+1)+' · '+ref,{size:8.5});};
            referenceList();
            const legend=()=>{
                const labels=['pdfVisitMark','pdfMedianMark','pdfTwoMark','pdfThreeMark'].map(t);
                const segments=[[],[],[1.4,.8],[.35,.85]];
                ensure(14);
                for(let i=0;i<labels.length;i++){
                    const left=margin+(rtl?3-i:i)*46.5;
                    doc.setDrawColor(45).setLineWidth(i===0?.55:.24).setLineDashPattern(segments[i],0).line(left,y-1,left+7,y-1);
                    if(i===0)doc.setFillColor(35).circle(left+3.5,y-1,.65,'F');
                    place(labels[i],rtl?left+45:left+9,y,{size:8.5});
                }
                doc.setLineDashPattern([],0);y+=5;
                line(t('pdfPointStyles'),{size:8.5});
            };
            for(let i=0;i<panels.length;i+=2){
                const pair=panels.slice(i,i+2);
                const required=panelHeight+(i+2>=panels.length?13:0);
                const nextPage=y+required>bottom;
                ensure(required);
                if(nextPage){identity();referenceList();}
                const panelWidth=pair.length===1?width:(width-gap)/2;
                pair.forEach((panel,index)=>this.drawReportChart(doc,panel,margin+(rtl?pair.length-1-index:index)*(panelWidth+gap),y,panelWidth,{place,t,number,rtl,referenceCode:references.length>1?'R'+(references.indexOf(panel.reference)+1):'',date}));
                y+=panelHeight;
            }
            legend();
            if(panels.some(panel=>panel.key==='armCircumferenceForAge'))line(t('pdfMuacDistinction'),{size:9});
            const indexed=panels.map(panel=>new Map(panel.points.map(point=>[point.index,point.value])));
            const rows=chartData.entries.flatMap((visit,i)=>indexed.some(values=>values.has(i))?[{visit,i}]:[]);
            heading(t('pdfHistoryShort'));
            const recent=rows.slice(-8);
            if(recent.length<rows.length)line(t('pdfRecentVisits').replace('{count}',number(recent.length)).replace('{total}',number(rows.length)),{size:9});
            // Split wide histories by reference and indicator to keep every column readable.
            for(let i=0;i<panels.length;i+=4){
                const subset=panels.slice(i,i+4),values=indexed.slice(i,i+4);
                const indexedReferences=references.length>1;
                table([t('measurementDate'),t('ageDays'),...subset.map(p=>t(p.key)+(p.growth?' · '+this.chartUnit(p.key):' · Z')+
                    (indexedReferences?' · R'+(references.indexOf(p.reference)+1):''))],
                    recent.map(({visit,i:index})=>[date(visit.child.measurementDate),number(visit.child.ageDays),...values.map((column,j)=>column.has(index)?number(column.get(index),subset[j].growth?1:2):'—')]),true);
            }
            if(key===active.at(-1)&&!selected.has(this.reportSections[0]))line(t('appUsageNotice'),{size:9});
        }
        const count=doc.getNumberOfPages();
        const issued=date(now.toISOString().slice(0,10))+' '+now.toISOString().slice(11,16)+' UTC';
        for(let i=1;i<=count;i++){
            doc.setPage(i);
            place(language==='ar'?t('brand'):'Z-Score Niger',rtl?right:margin,12,{size:17,bold:true});
            place(t(pages.get(i)||active[0]),rtl?margin:right,12,{size:11,bold:true,align:rtl?'left':'right'});
            const reference=pageReferences.get(i);
            if(reference)place(reference,rtl?margin:right,16,{size:7.5,align:rtl?'left':'right'});
            doc.setDrawColor(50).setLineWidth(.25);
            doc.line(margin,reference?19:16,right,reference?19:16);doc.line(margin,282,right,282);
            place(t('pdfExported')+' '+issued,margin,287,{size:8,align:'left'});
            place(t('pdfSensitive'),105,287,{size:8,align:'center'});
            place(i+'/'+count,right,287,{size:8,align:'right'});
        }
    }
    static chartUnit(key) {
        return SupplementaryPDF.definitions[key]?.unit||{weightForAge:'kg',heightForAge:'cm',bmiForAge:'kg/m²'}[key]||'';
    }
    static drawReportChart(doc,panel,left,top,width,{place,t,number,rtl,referenceCode='',date=value=>value}) {
        const axisLeft=left+12,axisRight=left+width-(panel.growth?10:4),axisTop=top+10,axisBottom=top+49;
        let {xMin,xMax,min,max}=panel;
        if(panel.growth&&panel.points.length>1){
            const month=panel.ig?28:30.4375;
            const ages=panel.points.reduce(({first,last},p)=>({first:Math.min(first,p.day),last:Math.max(last,p.day)}),{first:Infinity,last:-Infinity});
            xMin=Math.max(xMin,Math.floor(ages.first/month-1)*month);
            xMax=Math.min(xMax,Math.ceil(ages.last/month+1)*month);
            const values=[...panel.points.map(p=>p.value),...panel.curves.flatMap(curve=>curve.segments.flatMap(segment=>
                segment.filter(p=>p.day>=xMin-month&&p.day<=xMax+month).map(p=>p.value)))];
            const bounds=values.reduce(({low,high},value)=>({low:Math.min(low,value),high:Math.max(high,value)}),{low:Infinity,high:-Infinity});
            const pad=Math.max(.3,(bounds.high-bounds.low)*.08);
            min=Math.max(0,bounds.low-pad);max=bounds.high+pad;
        }
        const x=day=>axisLeft+(day-xMin)/(xMax-xMin||1)*(axisRight-axisLeft);
        const y=value=>axisBottom-(value-min)/(max-min)*(axisBottom-axisTop);
        const unit=panel.growth?this.chartUnit(panel.key):'Z';
        const chartTitle=t(panel.key)+' · '+unit+(referenceCode?' · '+referenceCode:'');
        doc.setFontSize(9.5);const titleLines=doc.splitTextToSize(chartTitle,width-2);
        titleLines.forEach((label,i)=>place(label,rtl?left+width:left,top+2+i*3.6,{size:9.5,bold:true}));
        const zLevels=[-3,-2,0,2,3];
        const grid=panel.growth?Array.from({length:4},(_,i)=>min+(max-min)*i/3):zLevels;
        const dash=z=>Math.abs(z)===3?[.35,.85]:Math.abs(z)===2?[1.4,.8]:[];
        for(const level of grid){
            doc.setDrawColor(panel.growth?198:95).setLineWidth(.19).setLineDashPattern(panel.growth?[]:dash(level),0).line(axisLeft,y(level),axisRight,y(level));
            place(number(level,panel.growth?1:0),axisLeft-1,y(level)+.8,{size:8,align:'right'});
        }
        doc.saveGraphicsState().rect(axisLeft,axisTop,axisRight-axisLeft,axisBottom-axisTop,null).clip().discardPath();
        for(const curve of panel.curves||[]){
            doc.setDrawColor(65).setLineWidth(curve.z===0?.42:.31).setLineDashPattern(dash(curve.z),0);
            // A continuous vector path maintains the dash pattern across all samples.
            for(const segment of curve.segments){
                if(segment.length<2)continue;
                doc.moveTo(x(segment[0].day),y(segment[0].value));
                for(const point of segment.slice(1))doc.lineTo(x(point.day),y(point.value));
                doc.stroke();
            }
        }
        doc.restoreGraphicsState();
        if(panel.growth){
            const marks=[];
            for(const curve of panel.curves||[]){
                let last=null;
                for(const segment of curve.segments){
                    for(let i=0;i<segment.length;i++){
                        const p=segment[i];
                        if(p.day>=xMin&&p.day<=xMax&&(!last||p.day>last.day))last=p;
                        const q=segment[i+1];
                        if(q&&p.day<xMax&&q.day>xMax)last={day:xMax,value:p.value+(q.value-p.value)*(xMax-p.day)/(q.day-p.day)};
                    }
                }
                if(last&&last.value>=min&&last.value<=max)marks.push({z:curve.z,at:y(last.value)});
            }
            marks.sort((a,b)=>a.at-b.at);
            const spacing=2.9;
            marks.forEach((m,i)=>m.labelY=Math.max(axisTop+1,m.at,i?marks[i-1].labelY+spacing:axisTop+1));
            for(let i=marks.length-1;i>=0;i--)marks[i].labelY=Math.min(marks[i].labelY,i===marks.length-1?axisBottom:marks[i+1].labelY-spacing);
            for(const m of marks){doc.setDrawColor(100).setLineWidth(.16).setLineDashPattern([],0).line(axisRight,m.at,axisRight+1.1,m.labelY);place((m.z>0?'+':'')+number(m.z),axisRight+1.5,m.labelY+.8,{size:7.5,align:'left'});}
        }
        doc.setDrawColor(34).setLineWidth(.52).setLineDashPattern([],0);
        for(const [a,b] of panel.lines)doc.line(x(a.day),y(a.value),x(b.day),y(b.value));
        const radius=panel.points.length>30?.48:.75;
        for(const point of panel.points){
            doc.setFillColor(point.imported?255:30);
            if(point.estimated)doc.rect(x(point.day)-radius,y(point.value)-radius,2*radius,2*radius,'FD');
            else doc.circle(x(point.day),y(point.value),radius,'FD');
        }
        for(const point of new Set([panel.points[0],panel.points.at(-1)])){
            const px=x(point.day),py=y(point.value);
            const another=panel.points[0]!==point&&Math.abs(x(panel.points[0].day)-px)<12&&Math.abs(y(panel.points[0].value)-py)<4;
            if(!another)place(number(point.value,panel.growth?1:2),Math.max(axisLeft+4,Math.min(axisRight-4,px)),py<axisTop+4?py+4:py-1.7,{size:8,bold:true,align:'center'});
        }
        doc.setDrawColor(80).setLineWidth(.19);
        doc.line(axisLeft,axisTop,axisLeft,axisBottom);doc.line(axisLeft,axisBottom,axisRight,axisBottom);
        const ticks=panel.growth?Array.from({length:5},(_,i)=>xMin+(xMax-xMin)*i/4):[xMin,xMax];
        for(const day of ticks){
            const label=panel.growth?number(day/(panel.ig?7:panel.older?365.25:30.4375),panel.older&&(xMax-xMin)<1461?1:0):date(new Date(day*86400000).toISOString().slice(0,10));
            place(label,x(day),top+53,{size:8,align:day===xMin?'left':day===xMax?'right':'center'});
        }
        place(t(panel.growth?(panel.ig?'intergrowthPmaWeeks':panel.older?'referenceAgeAxisYears':'referenceAgeAxis'):'measurementDate'),(axisLeft+axisRight)/2,top+58,{size:8,align:'center'});
    }
    static build(entries, options, { jsPDF, autoTable, fonts, now = new Date() }) {
        if (!jsPDF || !autoTable || !fonts?.[0] || !fonts?.[1]) throw new Error('pdfUnavailable');
        if(options.layout!==undefined&&!['compact','detailed'].includes(options.layout))throw new Error('pdfInvalid');
        const model = this.model(entries, options), {t, language, rows} = model;
        const batch = rows.length > 1 || options.mode === 'batch', rtl = language === 'ar';
        const doc = new jsPDF({orientation:batch?'landscape':'portrait',unit:'mm',format:'a4',compress:true,putOnlyUsedFonts:true});
        for (const [i, style] of ['normal','bold'].entries()) {
            const name = 'Amiri-' + style + '.ttf'; doc.addFileToVFS(name, fonts[i]); doc.addFont(name, 'Amiri', style);
        }
        doc.setFont('Amiri','normal'); doc.setLineHeightFactor(1.15);
        // Stored strings are logical Unicode. AutoTable must use the same Bidi options as headings.
        const drawText=doc.text.bind(doc),bidi=new jsPDF.__bidiEngine__({isInputVisual:false,isOutputVisual:true,isOutputRtl:false,isSymmetricSwapping:true});
        const visual=value=>{
            const ltr=rtl&&!batch&&/^(?:[<>]\s*)?[+−-]?\d[\d\s.,]*(?:\s(?:cm|mm|kg|g|kg\/m²))?$/.test(value);
            const logical=ltr?'\u200E'+value+'\u200E':value;
            return bidi.doBidiReorder(doc.processArabic(logical)).replace(/[\u200E\u200F]/g,'');
        };
        doc.text=(value,x,y,options={})=>drawText(Array.isArray(value)?value.map(visual):visual(value),x,y,{...options,isInputVisual:true,isOutputVisual:true,isOutputRtl:false});
        // Display unsupported characters explicitly rather than silently losing identity text.
        const glyph = doc.getFont().metadata.characterToGlyph.bind(doc.getFont().metadata);
        const safe = value => Array.from(this.clean(value), char => char === '\n' || glyph(char.codePointAt(0)) ? char : ({'≥':'>=','≤':'<='}[char] || '[U+' + char.codePointAt(0).toString(16).toUpperCase() + ']')).join('')
            .replace(/\b\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z)?\b/g, value => '\u200E'+value+'\u200E');
        const width = doc.internal.pageSize.getWidth(), height = doc.internal.pageSize.getHeight(), margin = 12;
        const compact=batch&&options.layout==='compact';
        const title = t(compact?'pdfCompactTitle':batch?'pdfBatchTitle':options.sections?.[0]||'pdfSingleReport'), issued = now.toISOString();
        doc.setProperties({title:t('brand')+' - '+title,subject:t('pdfStoredOnly'),author:t('brand'),creator:'Z-score Niger local PDF'});
        doc.setLanguage(language); doc.setCreationDate(now);
        if(!batch){
            // Standard PDF sans-serif for Western text; keep the embedded Arabic Unicode font for RTL and identities outside WinAnsi.
            const normalize=value=>this.clean(value).replace(/[\u202f\u00a0]/g,' ').replace(/−/g,'-').replace(/≥/g,'>=').replace(/≤/g,'<=');
            const western=value=>/^[\x20-\x7e\xa0-\xff\nœŒ‘’“”–—…€]*$/u.test(normalize(value));
            const strings=[...Object.values(options.translations[language]),...rows.flatMap(r=>[...r.identity,...r.measures,...r.scores,...r.percentiles,...r.notes])];
            const individualFont=!rtl&&strings.every(western)?'helvetica':'Amiri';
            const individualSafe=individualFont==='helvetica'?normalize:safe;
            this.individual(doc,autoTable,model,entries[0],{...options,individualFont},individualSafe,now);
            if(options.print)doc.internal.events.subscribe('putPage',({pageNumber})=>{
                // Native PDF action on opening the first page.
                if(pageNumber===1)doc.internal.write('/AA << /O << /S /Named /N /Print >> >>');
            });
            return {bytes:doc.output('arraybuffer'),pages:doc.getNumberOfPages(),entries:1};
        }
        const text = (value, y, size = 10, bold = false) => {
            doc.setFont('Amiri',bold?'bold':'normal');doc.setFontSize(size);
            const lines = doc.splitTextToSize(safe(value),width-2*margin);
            doc.text(lines,rtl?width-margin:margin,y,{align:rtl?'right':'left'});
            return y + lines.length * size / doc.internal.scaleFactor * 1.15 + 2;
        };
        const headed=new Set();
        const header = () => {
            const page=doc.internal.getCurrentPageInfo().pageNumber;if(headed.has(page))return;headed.add(page);
            doc.setTextColor(23,99,72); text(t('brand')+' - '+title,12,15,true);
            doc.setTextColor(35); text(t('pdfStoredOnly')+' | '+issued,20,9);
            doc.setDrawColor(190); doc.line(margin,25,width-margin,25);
        };
        header();let y=29;
        y=text(t('appUsageNotice'),y,10);
        if(model.hasPercentiles)y=text(t('percentileReportHelp'),y,9);
        if(model.stale) y=text(t('stale'),y,10,true);
        const base = {theme:'grid',margin:{top:29,bottom:compact?24:19,left:margin,right:margin},startY:y,
            styles:{font:'Amiri',fontStyle:'normal',fontSize:11,textColor:25,lineColor:210,lineWidth:.15,cellPadding:2,overflow:'linebreak',halign:rtl?'right':'left',valign:'top'},
            headStyles:{fontStyle:'bold',fillColor:[23,99,72],textColor:255},alternateRowStyles:{fillColor:[247,250,248]},
            rowPageBreak:'avoid',showHead:'everyPage',willDrawPage:()=>header(),
            didParseCell:data=>{data.cell.text=data.cell.text.map(safe);}};
        {
            if(model.provenances.length){
                autoTable(doc,{...base,head:[[t('referenceVersion')+' / '+t('engineVersion')]],body:model.provenances.map((p,i)=>['R'+(i+1)+' | '+p[0]+' | '+p[1]]),styles:{...base.styles,fontSize:9,cellPadding:1.5}});
                y=doc.lastAutoTable.finalY+3;
            }
            let widths,head,body;
            if(compact){
                const reduced=this.compact(model);
                autoTable(doc,{...base,startY:y,head:[[t('pdfCompactLegend')]],body:[[t('pdfCompactHelp')]],styles:{...base.styles,fontSize:10,cellPadding:1.5}});y=doc.lastAutoTable.finalY+3;
                let legendHead=[t('pdfCompactCode'),t('pdfCompactMeaning')],legend=reduced.legend;
                if(rtl){legendHead.reverse();legend=legend.map(row=>[...row].reverse());}
                autoTable(doc,{...base,startY:y,head:[legendHead],body:legend,styles:{...base.styles,fontSize:10,cellPadding:1.5}});y=doc.lastAutoTable.finalY+3;
                widths=model.indicators.length===4?[8,35,22,57,20,20,20,20,71]:model.indicators.length===2?[8,42,25,62,31.5,31.5,73]:[8,42,25,62,21,21,21,73];
                head=['pdfNumber','pdfCompactIdentity','measurementDate','pdfMeasures',...model.indicators,'pdfNotes'].map(t);body=reduced.body;
            }else{
                widths=model.indicators.length===4?[9,40,48,29,29,29,29,60]:model.indicators.length===2?[9,45,56,51,51,61]:[9,45,56,34,34,34,61];head=model.keys.map(t);body=rows.map(r=>[String(r.index),r.identity.join('\n'),r.compactMeasures.join('\n'),...r.scores.map((s,i)=>this.scoreWithPercentile(r,i)),[r.provenance||'',r.calculatedAt,...r.notes].join('\n')]);
            }
            if(rtl){head.reverse();body=body.map(r=>r.reverse());widths.reverse();}
            const continuedPages=new Set();
            autoTable(doc,{...base,startY:y,styles:{...base.styles,fontSize:compact?9:10,cellPadding:compact?1:1.5},head:[head],body,columnStyles:Object.fromEntries(widths.map((cellWidth,i)=>[i,{cellWidth}])),
                didDrawCell:data=>{
                    const index=this.continuedRowIndex(data,rtl),page=doc.internal.getCurrentPageInfo().pageNumber;
                    if(index===null||continuedPages.has(page))return;
                    continuedPages.add(page);
                    const size=doc.getFontSize(),color=doc.getTextColor();
                    doc.setFontSize(8);doc.setTextColor(35);
                    doc.text(safe(t('pdfRowContinuation').replace('{number}',index)),rtl?width-margin:margin,27.5,{align:rtl?'right':'left'});
                    doc.setFontSize(size);doc.setTextColor(color);
                }});
        }
        const pages=doc.getNumberOfPages();
        for(let i=1;i<=pages;i++){
            doc.setPage(i);doc.setTextColor(60);doc.setFont('Amiri','normal');doc.setFontSize(9);
            doc.setDrawColor(190);doc.line(margin,height-(compact?20:15),width-margin,height-(compact?20:15));
            if(compact)doc.text(safe(t('pdfCompactSeeLegend')),rtl?width-margin:margin,height-15,{align:rtl?'right':'left'});
            doc.text(safe(t('pdfSensitive')),rtl?width-margin:margin,height-10,{align:rtl?'right':'left'});
            doc.text(String(i)+' / '+String(pages),rtl?margin:width-margin,height-10,{align:rtl?'left':'right'});
        }
        return {bytes:doc.output('arraybuffer'),pages,entries:rows.length};
    }
}
if(typeof module!=='undefined'&&module.exports)module.exports={PDFManager};
