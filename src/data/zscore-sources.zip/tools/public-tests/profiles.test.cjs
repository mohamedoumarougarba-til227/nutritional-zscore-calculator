'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {ClinicalEngine}=require('../../src/js/services/clinical-engine.js');global.ClinicalEngine=ClinicalEngine;
const {GrowthEngine}=require('../../src/js/services/growth-engine.js');
const {GrowthProfile}=require('../../src/js/services/growth-profile.js');
const {HistoryManager}=require('../../src/js/services/history-manager.js');global.HistoryManager=HistoryManager;
const {TransferManager}=require('../../src/js/services/transfer-manager.js');
const {EncryptedBackup}=require('../../src/js/services/encrypted-backup.js');
const {CSVManager}=require('../../src/js/services/csv-manager.js');global.CSVManager=CSVManager;
const {PDFManager}=require('../../src/js/services/pdf-manager.js');
const {LotAnalysis}=require('../../src/js/components/lot-analysis.js');global.LotAnalysis=LotAnalysis;
const {GrowthChart}=require('../../src/js/components/growth-chart.js');global.GrowthChart=GrowthChart;
const {WorkspaceApp}=require('../../src/js/workspace-app.js');
const {ReportingExport}=require('../../src/js/services/reporting-export.js');
const data=name=>JSON.parse(fs.readFileSync(path.join(__dirname,'../../src/data',name),'utf8'));
const engine=new GrowthEngine(data('who-official.json'),data('who-2007.json'),data('who-additional.json'),data('cdc-growth.json'));
const input=extra=>({caseId:'FICTIF-PROFILE',name:'FICTIF-PROFILE',ageMode:'months',ageYears:3,ageMonths:0,weight:14000,height:95,gender:'F',position:'H',oedema:'n',measurementDate:'2026-10-26',...extra});
const validate=entry=>{HistoryManager.checkChild(entry.child);HistoryManager.checkResult(entry.result,new Set([entry.child.id]));HistoryManager.checkPair(entry.child,entry.result);};
global.localStorage=Object.create(null);
Object.defineProperties(global.localStorage,{getItem:{value:key=>global.localStorage[key]??null},setItem:{value:(key,v)=>{global.localStorage[key]=String(v);}}});

test('reference policy is explicit, WHO remains default and US uses WHO before 24 months then CDC to <240',()=>{
    const who=engine.calculate(input());assert.equal(who.result.referenceFamily,'WHO2006');assert.equal(who.child.ageDomainVersion,2);assert.equal(who.result.profileContext,undefined);validate(who);
    const infant=engine.calculate(input({growthProfile:'us',ageYears:1,ageMonths:11,position:'L'}));
    assert.equal(infant.result.referenceFamily,'WHO2006');assert.equal(infant.result.ageInMonths,23);assert.equal(infant.child.ageDomainVersion,3);validate(infant);
    const cdc=engine.calculate(input({growthProfile:'us',ageYears:2,ageMonths:0}));
    assert.equal(cdc.result.referenceFamily,'CDC2000');assert.equal(cdc.child.totalAgeMonths,24);assert.equal(cdc.result.ageInMonths,24.5);validate(cdc);
    const last=engine.calculate(input({growthProfile:'us',ageYears:19,ageMonths:11,weight:65000,height:170}));validate(last);assert.equal(last.result.ageInMonths,239.5);
    assert.throws(()=>engine.calculate(input({ageYears:19,ageMonths:1})),/ageInvalid/);
    assert.throws(()=>engine.calculate(input({growthProfile:'us',ageYears:20})),/ageInvalid/);
    assert.throws(()=>engine.calculate(input({growthProfile:'other'})),/growthProfileInvalid/);
});

test('US exact age is not silently shifted and metadata distinguishes it from completed months',()=>{
    const exact=engine.calculate(input({growthProfile:'us',ageMode:'days',ageDays:731}));validate(exact);
    assert.equal(exact.result.ageInMonths,731/30.4375);assert.equal(exact.result.profileContext.agePrecision,'exact');
    const estimated=engine.calculate(input({growthProfile:'us'}));validate(estimated);
    assert.equal(estimated.result.profileContext.reportedAgeInMonths,36);assert.equal(estimated.result.ageInMonths,36.5);
    assert.equal(estimated.result.profileContext.agePrecision,'completedMonths');assert.ok(estimated.result.warnings.includes('cdcCompletedMonths'));
    assert.equal(estimated.result.weightForHeight.notApplicable,true);
    assert.equal(estimated.result.nutrition.category,'nutritionIncomplete');
    assert.ok(estimated.result.nutrition.missing.includes('weightForHeight'));
});

test('saved WHO 4.2 results and mixed-profile workspace stay readable without rewriting existing visits',()=>{
    const who=engine.calculate(input());who.result.engineVersion='4.2.0';
    const saved=JSON.stringify(who),us=engine.calculate(input({growthProfile:'us'}));
    const workspace={version:1,mode:'batch',draft:{},batchDraft:{},single:null,batch:[who,us],paste:''};
    HistoryManager.checkWorkspace(workspace);assert.equal(JSON.stringify(who),saved);
    const reordered=structuredClone(us);reordered.result.profileContext=Object.fromEntries(Object.entries(reordered.result.profileContext).reverse());validate(reordered);
    assert.equal(GrowthProfile.read(who.child),'who');assert.equal(GrowthProfile.read(us.child),'us');
});

test('saved CDC rejects mismatched age, reference, WHO category, method, centile and inconsistent child/result pairs',()=>{
    const original=engine.calculate(input({growthProfile:'us'}));validate(original);
    for(const mutate of [
        e=>{e.result.profileContext.reportedAgeInMonths++;},
        e=>{e.result.referenceVersion='WHO-2006-unverified';},
        e=>{e.result.bmiForAge.classification='bmiWithin';},
        e=>{e.result.bmiForAge.percentile=50;},
        e=>{e.result.bmiForAge.method='WHO-LMS';},
        e=>{e.result.bmiForAge.sigma+=1;},
        e=>{e.child.ageDomainVersion=2;},
        e=>{delete e.result.profileContext;},
        e=>{e.result.correctedHeight+=.1;},
        e=>{e.result.weightForHeight.error='noWeightForHeight2007';}
    ]){const changed=structuredClone(original);mutate(changed);assert.throws(()=>validate(changed),/importInvalid|importVersion/);}
    const infant=engine.calculate(input({growthProfile:'us',ageYears:1}));
    infant.child=GrowthEngine.normalize({...infant.child,growthProfile:'who'});
    assert.throws(()=>validate(infant),/importInvalid/);
});

test('CDC position, oedema and extended BMI remain bound to saved measurements and source method',()=>{
    const lying=engine.calculate(input({growthProfile:'us',position:'L'}));validate(lying);assert.equal(lying.result.correctedHeight,94.2);
    const swollen=engine.calculate(input({growthProfile:'us',oedema:'y'}));validate(swollen);assert.equal(swollen.result.bmi,null);assert.equal(swollen.result.bmiForAge.error,'oedemaWarning');
    const extended=engine.calculate(input({growthProfile:'us',weight:30000,height:100}));validate(extended);
    assert.equal(extended.result.bmiForAge.method,'CDC2022-extended-BMI');assert.ok(extended.result.bmiForAge.zscoreRaw>1.645);
    const saved=JSON.stringify(extended);engine.calculate(input());assert.equal(JSON.stringify(extended),saved);
});

test('mixed WHO/CDC stream backup and encrypted export preserve each visit context and raw results',async()=>{
    const entries=[engine.calculate(input()),engine.calculate(input({growthProfile:'us'}))];
    const records={children:entries.map(e=>e.child),results:entries.map(e=>e.result),sessions:[],settings:[]};
    const storage={async visitArchive(fn){for(const store of TransferManager.stores)for(const record of records[store])fn(store,structuredClone(record));}};
    const before=JSON.stringify(records),plain=await new TransferManager(storage).export({language:'fr',growthProfile:'us'});
    const verified=await TransferManager.inspect(plain);assert.equal(verified.validator.counts.children,2);assert.equal(verified.validator.counts.results,2);
    const cipher=await EncryptedBackup.encrypt(plain,'fictitious-profile-test-only'),restored=await EncryptedBackup.decrypt(cipher,'fictitious-profile-test-only');
    assert.equal(await restored.text(),await plain.text());await TransferManager.inspect(restored);
    assert.equal(JSON.stringify(records),before);
    const rows=(await restored.text()).trim().split('\n').map(JSON.parse).filter(r=>r.store==='results');
    assert.deepEqual(rows.map(r=>r.record),records.results);
    const remap=TransferManager.remapper('fictitious-profile-copy'),copy={child:remap('children',entries[1].child),result:remap('results',entries[1].result)};
    validate(copy);assert.notEqual(copy.child.id,entries[1].child.id);assert.notEqual(copy.result.id,entries[1].result.id);
    assert.equal(copy.child.visitId,entries[1].child.visitId);assert.equal(copy.result.imported,true);
    assert.deepEqual(copy.result.profileContext,entries[1].result.profileContext);
    assert.equal(JSON.stringify(records),before);
});

test('CSV imports pin a default profile once and explicit row profiles survive mixed export metadata',async()=>{
    const header='name,ageYears,ageMonths,weight,height,gender,position,oedema,measurementDate';
    const csv=header+'\nFICTIF-CSV,19,11,65000,170,M,H,n,2026-10-26';
    assert.throws(()=>CSVManager.parse(csv,{extended:true}),/ageInvalid/);
    const [child]=CSVManager.parse(csv,{extended:true,growthProfile:'us'});assert.equal(child.growthProfile,'us');
    const asyncRows=await CSVManager.parseAsync(csv,{extended:true,growthProfile:'us'});assert.equal(asyncRows[0].totalAgeMonths,239);
    const mixed=header+',growthProfile\nFICTIF-A,3,0,14000,95,F,H,n,2026-10-26,who\nFICTIF-B,3,0,14000,95,F,H,n,2026-10-26,us';
    const entries=CSVManager.parse(mixed,{extended:true,growthProfile:'us'}).map(c=>engine.calculate(c));
    assert.deepEqual(entries.map(e=>e.result.referenceFamily),['WHO2006','CDC2000']);
    const lines=[...CSVManager.rows(CSVManager.results(entries))],columns=lines.shift();
    const cell=(row,key)=>row[columns.indexOf(key)];
    assert.ok(lines.every(row=>row.length===columns.length));
    assert.equal(cell(lines[1],'growth_profile'),'us');assert.equal(cell(lines[1],'reported_age_months'),'36');assert.equal(cell(lines[1],'age_in_months'),'36.5');
    assert.equal(cell(lines[1],'bmiForAge_method'),entries[1].result.bmiForAge.method);
    assert.equal(Number(cell(lines[1],'bmiForAge_p95')),entries[1].result.bmiForAge.p95);
    assert.equal(cell(lines[0],'bmiForAge_method'),'');
    assert.throws(()=>CSVManager.parse(mixed.replace(',us',',unknown'),{extended:true}),/growthProfileInvalid/);
});

test('CDC batch categories and denominators stay separate from WHO and do not become population prevalence',()=>{
    const us=engine.calculate(input({growthProfile:'us'})),who=engine.calculate(input());
    const swollen=engine.calculate(input({growthProfile:'us',oedema:'y'})),flagged=engine.calculate(input({growthProfile:'us',weight:40000}));
    assert.equal(flagged.result.bmiForAge.flagged,true);
    const entries=[us,structuredClone(us),swollen,flagged,who],before=JSON.stringify(entries);
    const model=LotAnalysis.build(entries,engine.cdc.data.referenceVersion,{family:'CDC2000'}),bmi=model.indicators.find(i=>i.key==='bmiForAge');
    assert.equal(model.ages.from2to4,5);assert.equal(model.identifiedCases,1);assert.equal(model.total,5);
    assert.equal(bmi.usable,2);assert.equal(bmi.suspended,1);assert.equal(bmi.flagged,1);assert.equal(bmi.unverified,1);
    assert.ok(bmi.categories.every(c=>c.key.startsWith('cdc')&&c.denominator===2));
    assert.equal(bmi.categories.reduce((n,c)=>n+c.count,0),2);assert.ok(!model.indicators.some(i=>i.key==='weightForHeight'));
    const app=Object.assign(Object.create(WorkspaceApp.prototype),{engine,state:{batch:entries}});
    assert.deepEqual(app.lotModels().map(m=>[m.family,m.total]),[['WHO2006',1],['CDC2000',4]]);
    const report=ReportingExport.aggregate(entries,'202610');assert.equal(report.unit,'measurement-rows');assert.equal(report.counts.rows,5);
    // CDC BMI categories are never treated as WHO acute malnutrition criteria.
    assert.equal(us.result.nutrition.category,'nutritionIncomplete');
    assert.equal(report.counts.nutritionSevere,1); // Only the visit with present oedema.
    assert.equal(JSON.stringify(entries),before);
});

test('CDC curves use the extended BMI inverse, stored effective ages and reference-separated points without changing visits',()=>{
    const entries=[engine.calculate(input({growthProfile:'us'})),engine.calculate(input())],before=JSON.stringify(entries);
    const model=GrowthChart.referenceModel(entries,engine.cdc);assert.equal(model.cdc,true);assert.equal(model.panels.length,3);
    const bmi=model.panels.find(p=>p.key==='bmiForAge'),age=36.5;
    assert.equal(bmi.points.length,1);assert.equal(bmi.points[0].day,age*30.4375);assert.equal(bmi.points[0].estimated,true);assert.equal(bmi.omitted,1);
    const p=bmi.curves.find(c=>c.z===3).segments[0].find(p=>p.day===age*30.4375);
    assert.equal(p.value,engine.cdc.valueAtZ('bmiForAge','F',age,3));
    assert.ok(Math.abs(p.value-require('../../src/js/services/reference-cdc.js').CDCReference.measurement(3,engine.cdc.params('bmiForAge','F',age)))>.1);
    assert.ok(bmi.curves.every(c=>c.segments[0].every(p=>p.day<240*30.4375)));
    const scoreModel=GrowthChart.build(entries,engine.cdc.data.referenceVersion);assert.equal(scoreModel.panels.length,3);assert.ok(scoreModel.panels.every(p=>p.points.length===1&&!p.connect));
    assert.equal(JSON.stringify(entries),before);
});

test('Settings growth profile selector reaches popup through header action',async()=>{
    const calls=[];
    const ui=Object.assign(Object.create(WorkspaceApp.prototype),{openChoice:(id,kind)=>calls.push([id,kind])});
    ui.openHeaderPanel('growthProfile');
    assert.deepEqual(calls,[['growthProfile-button','growthProfile']]);
    calls.length=0;
    const dispatch=Object.assign(Object.create(WorkspaceApp.prototype),{readForms(){},openHeaderPanel:kind=>calls.push(['action',kind])});
    await dispatch.action('header-panel',{dataset:{kind:'growthProfile'},closest(){return null;}});
    assert.deepEqual(calls,[['action','growthProfile']]);
    for(const key of ['fr','en','ar']){
        const translations=data('interface-translations.json');
        const app=Object.assign(Object.create(WorkspaceApp.prototype),{translations,prefs:{language:key,theme:'light',growthProfile:'who'}});
        const settings=app.settingsHTML(),form=app.formHTML('single',app.emptyDraft('who'));
        assert.ok(settings.includes(app.t('growthProfileDefault')));
        assert.ok(settings.includes(app.t('growthProfileDefaultHelp')));
        assert.ok(settings.includes(app.t('careProtocolDefault')));
        assert.ok(settings.includes('data-action="check-update"'));
        assert.ok(settings.includes('settings-layout'));
        assert.ok(form.includes(app.t('growthProfileVisit')));
        assert.ok(form.includes('data-info="growthProfileVisitHelp"'));
        assert.ok(!form.includes('name=\"growthProfile\" disabled'));
    }
});

test('CDC results explain WHO-only supplementary scores and WHO screening without changing stored measures',()=>{
    const record=engine.calculate(input({growthProfile:'us',ageYears:3,ageMonths:2,headCircumference:48,muac:140}));
    const before=JSON.stringify(record),translations=data('interface-translations.json');
    for(const language of ['fr','en','ar']){
        const ui=Object.assign(Object.create(WorkspaceApp.prototype),{prefs:{language,growthProfile:'us'},translations});
        const form=ui.formHTML('single',record.child),html=ui.resultsHTML(record,false,true);
        assert.ok(form.includes(translations[language].additionalMeasuresWho));
        assert.ok(html.includes(translations[language].growthResultsCdc));
        assert.ok(html.includes(translations[language].additionalResultsWho));
        assert.ok(html.includes(translations[language].screeningTitleWho));
    }
    assert.equal(JSON.stringify(record),before);
});

test('profile settings and new visits preserve existing work and never silently convert a WHO visit to CDC',async t=>{
    const previous=global.document;t.after(()=>{global.document=previous;});global.document={getElementById:()=>({close(){}})};
    const who=engine.calculate(input()),before=JSON.stringify(who);
    const app=Object.assign(Object.create(WorkspaceApp.prototype),{prefs:{language:'fr',theme:'light',growthProfile:'who'},page:'settings',readForms(){},persistPreferences(){},applyPreferences(){},render(){},toast(){},async saveImmediate(){}});
    app.state={...app.emptyWorkspace(),draft:structuredClone(who.child),single:who};
    app.setPreference('growthProfile','us');assert.equal(app.prefs.growthProfile,'us');assert.equal(app.state.draft.growthProfile,undefined);assert.equal(JSON.stringify(who),before);
    assert.equal(app.emptyDraft().growthProfile,'us');assert.equal(app.state.batchDraft.growthProfile,'us');
    app.history={async save(){}};app.checkpoint=()=>{};
    const original={version:1,mode:'single',draft:structuredClone(who.child),batchDraft:{},single:structuredClone(who),batch:[],paste:''};
    await app.restore({metadata:{workspace:original}});
    assert.equal(app.state.draft.growthProfile,'who');assert.equal(engine.calculate(app.state.draft).result.referenceFamily,'WHO2006');assert.equal(JSON.stringify(who),before);
    await app.action('new-visit',{});assert.equal(app.state.draft.growthProfile,'who');assert.equal(app.state.draft.caseId,who.child.caseId);assert.equal(JSON.stringify(who),before);
    app.state.single=engine.calculate(input({growthProfile:'us'}));await app.action('new-visit',{});assert.equal(app.state.draft.growthProfile,'us');
});

test('CDC result views, compact/detailed PDF models and charts explain the actual method in FR/EN/AR',()=>{
    const entry=engine.calculate(input({growthProfile:'us',weight:30000,height:100})),before=JSON.stringify(entry),translations=data('interface-translations.json');
    for(const language of ['fr','en','ar']){
        const ui=Object.assign(Object.create(WorkspaceApp.prototype),{translations,prefs:{language,growthProfile:'us',theme:'light'},engine,state:{batch:[entry]}});
        const html=ui.resultsHTML(entry,false,true),charts=ui.chartsHTML([entry]);
        assert.ok(html.includes(ui.esc(ui.t('cdcSevereObesity'))));assert.ok(html.includes('CDC2022-extended-BMI'));assert.ok(html.includes(ui.esc(ui.t('calculationAgeMonths'))));
        assert.ok(charts.includes(ui.esc(ui.t('cdcChartTitle'))));assert.ok(charts.includes(entry.result.referenceVersion));assert.ok(!charts.includes('WHO-2007-'));
        const model=PDFManager.model([entry],{language,translations}),row=model.rows[0];
        assert.ok(row.notes.some(n=>n.includes('CDC2022-extended-BMI')));assert.ok(row.notes.some(n=>n.includes(ui.t('profileUS'))));assert.ok(row.scores.some(n=>n.includes(ui.t('cdcSevereObesity'))));
        const compact=PDFManager.compact(model,[entry]);assert.ok(compact.body[0].at(-1).includes(entry.result.referenceVersion));assert.ok(compact.body[0].some(text=>text.includes(ui.t('cdcSevereObesity'))));
        const lot=LotAnalysis.html(LotAnalysis.build([entry],engine.cdc.data.referenceVersion,{family:'CDC2000'}),ui,{exportButton:false});assert.ok(lot.includes(ui.esc(ui.t('cdcLotRules'))));
        assert.ok(ui.settingsHTML().includes(ui.esc(ui.t('profileUS'))));assert.ok(ui.formHTML('single',entry.child).includes('name="growthProfile"'));assert.ok(ui.formHTML('single',entry.child).includes('data-info="usAgeHelp"'));assert.ok(!ui.formHTML('single',entry.child).includes(translations[language].ageHint));
        for(const key of ['growthProfile','profileWHO','profileUS','cdcCoverage','cdcInterpretation','cdcCompletedMonths','cdcSevereObesity'])assert.notEqual(ui.t(key),key);
    }
    assert.equal(JSON.stringify(entry),before);
});

test('extended CDC centiles near 100 remain bounded in results, history and PDF without changing CSV or stored scores',()=>{
    const entry=engine.calculate(input({growthProfile:'us',gender:'M',ageYears:10,ageMonths:0,weight:70000,height:140}));
    const before=JSON.stringify(entry),csv=CSVManager.results([entry]),translations=data('interface-translations.json');
    assert.equal(entry.result.bmiForAge.method,'CDC2022-extended-BMI');assert.ok(entry.result.bmiForAge.percentile>99.95&&entry.result.bmiForAge.percentile<100);
    for(const language of ['fr','en','ar']){
        const ui=Object.assign(Object.create(WorkspaceApp.prototype),{translations,prefs:{language,growthProfile:'us',theme:'light'},engine,state:{batch:[entry]}});
        const bounded=ui.esc('> '+ui.number(99.9,1));
        assert.ok(ui.percentileHTML(entry.result.bmiForAge,entry.result).includes('P '+bounded));
        assert.ok(ui.resultsHTML(entry,false,true).includes('P '+bounded));
        assert.ok(ui.chartsHTML([entry]).includes('P '+bounded));
        const model=PDFManager.model([entry],{language,translations});assert.ok(model.rows[0].percentiles.includes('P > 99.9'));
        assert.ok(JSON.stringify(PDFManager.compact(model,[entry])).includes('P > 99.9'));
    }
    assert.equal(JSON.stringify(entry),before);assert.equal(CSVManager.results([entry]),csv);
});

test('centile presentation distinguishes tails, exact display boundaries and unavailable values in all languages',()=>{
    // Presentation-only inputs; these are not fixtures for recomputing a medical result.
    const entry=engine.calculate(input({growthProfile:'us'})),translations=data('interface-translations.json');
    for(const language of ['fr','en','ar']){
        const ui=Object.assign(Object.create(WorkspaceApp.prototype),{translations,prefs:{language}});
        for(const [percentile,operator,bound] of [[.000001,'< ',.1],[.099999,'< ',.1],[.1,'',.1],[50,'',50],[99.9,'',99.9],[99.900001,'> ',99.9],[99.999999,'> ',99.9]]){
            const copy=structuredClone(entry);Object.assign(copy.result.bmiForAge,{percentile,flagged:false,zscore:1});
            assert.ok(ui.percentileHTML(copy.result.bmiForAge,copy.result).includes('P '+ui.esc(operator+ui.number(bound,1))));
            assert.ok(PDFManager.model([copy],{language,translations}).rows[0].percentiles.includes('P '+operator+bound.toFixed(1)));
        }
        for(const percentile of [null,undefined,NaN,Infinity,0,100,-1,101,'99.99']){
            const copy=structuredClone(entry);copy.result.bmiForAge.percentile=percentile;
            assert.ok(ui.percentileHTML(copy.result.bmiForAge,copy.result).includes('P —'));
            assert.ok(PDFManager.model([copy],{language,translations}).rows[0].percentiles.includes('P --'));
        }
        const flagged=structuredClone(entry);flagged.result.bmiForAge.flagged=true;
        assert.ok(ui.percentileHTML(flagged.result.bmiForAge,flagged.result).includes('P —'));
        assert.ok(PDFManager.model([flagged],{language,translations}).rows[0].percentiles.includes('P --'));
    }
});

test('PDF supplementary centiles use the same bounds and omit flagged or unavailable positions without mutating measurements',()=>{
    const entry=engine.calculate(input({growthProfile:'who',ageYears:1,ageMonths:0,weight:8500,height:75,position:'L',headCircumference:46})),translations=data('interface-translations.json');
    for(const language of ['fr','en','ar'])for(const [percentile,flagged,expected] of [[99.999999,false,'P > 99.9'],[.000001,false,'P < 0.1'],[50,false,'P 50.0'],[99.999999,true,null],[null,false,null]]){
        const copy=structuredClone(entry),v=copy.result.additionalGrowth.indicators.headCircumferenceForAge;Object.assign(v,{percentile,flagged});
        const before=JSON.stringify(copy),notes=PDFManager.model([copy],{language,translations}).rows[0].notes;
        const note=notes.find(n=>n.startsWith(translations[language].headCircumferenceForAge+' : '));assert.ok(note);
        if(expected)assert.ok(note.includes(expected));else assert.ok(!note.includes(' | P '));
        assert.equal(JSON.stringify(copy),before);
    }
});


test('screening preference applies to new drafts only and PCIMA is restricted to WHO',t=>{
    const previous=global.document;t.after(()=>{global.document=previous;});global.document={getElementById:()=>({close(){}})};
    const app=Object.assign(Object.create(WorkspaceApp.prototype),{prefs:{language:'fr',theme:'dark',growthProfile:'who',careProtocol:''},page:'settings',readForms(){},persistPreferences(){},applyPreferences(){},render(){},toast(){}});
    app.state=app.emptyWorkspace();app.state.draft.name='FICTIF';const before=JSON.stringify(app.state.draft);
    app.setPreference('careProtocol','niger2025');assert.equal(app.prefs.careProtocol,'niger2025');assert.equal(JSON.stringify(app.state.draft),before);
    assert.equal(app.emptyDraft().careProtocol,'niger2025');assert.equal(app.state.batchDraft.careProtocol,'niger2025');
    app.setPreference('careProtocol','niger2023');assert.equal(app.state.batchDraft.careProtocol,'niger2023');
    app.setPreference('growthProfile','us');assert.equal(app.prefs.careProtocol,'');assert.equal(app.emptyDraft().careProtocol,'');assert.equal(app.state.batchDraft.careProtocol,'');
    app.setPreference('careProtocol','niger2025');assert.equal(app.prefs.careProtocol,'');assert.equal(JSON.stringify(app.state.draft),before);
    assert.equal(WorkspaceApp.defaultCareProtocol('intergrowth','niger2023'),'');
    assert.equal(WorkspaceApp.defaultCareProtocol('who','unknown'),'');
});


test('clinical workspace visual tabs preserve fields and original filtered lot indices',()=>{
    const translations=data('interface-translations.json');
    for(const language of ['fr','en','ar']){
        const app=Object.assign(Object.create(WorkspaceApp.prototype),{translations,prefs:{language,theme:'light',growthProfile:'who'}});
        const draft=app.emptyDraft();const html=app.formHTML('single',draft);
        for(const field of ['caseId','name','ageMode','measurementDate','weight','height','gender','position','oedema','muac','careProtocol','growthProfile','appetite'])assert.equal((html.match(new RegExp('name="'+field+'"','g'))||[]).length,1,field);
        const first=engine.calculate(input({name:'FICTIF A',caseId:'A'})),second=engine.calculate(input({name:'FICTIF B',caseId:'B'}));
        app.state={...app.emptyWorkspace(),batch:[first,second]};app.batchSearch='FICTIF B';const before=JSON.stringify(app.state);
        const view=app.batchDisplayView();assert.deepEqual(view.indices,[1]);assert.equal(view.entries[0],second);
        const table=app.tableHTML(view.entries,{compact:true,editable:true,indices:view.indices});assert.ok(table.includes('data-action="batch-correct" data-index="1"'));assert.ok(table.includes('data-action="quality-view" data-index="1"'));
        const result=app.resultsHTML(first);for(const key of ['summary','charts','details'])assert.ok(result.includes('id="single-view-'+key+'"'));assert.ok(!result.includes('id="single-view-history"'));assert.ok(result.includes('data-single-history'));assert.ok(result.includes('data-action="view-case"'));
        const summaryStart=result.indexOf('id="single-view-summary"'),chartsStart=result.indexOf('id="single-view-charts"'),detailsStart=result.indexOf('id="single-view-details"');
        assert.ok(result.indexOf('class="workspace-view-nav"')<summaryStart);
        assert.ok(result.indexOf('class="nutrition-result')>summaryStart&&result.indexOf('class="nutrition-result')<chartsStart);
        assert.ok(!result.slice(summaryStart,chartsStart).includes('measurement-snapshot detail-'));
        assert.ok(result.slice(detailsStart).includes('detail-measures'));assert.ok(result.slice(detailsStart).includes('detail-references'));
        assert.ok(!result.slice(chartsStart,detailsStart).includes('nutrition-result'));
        assert.equal(JSON.stringify(app.state),before);
    }
});


test('individual compact entry keeps each original input and age mode across profiles and languages',()=>{
    const translations=data('interface-translations.json');
    for(const language of ['fr','en','ar'])for(const profile of ['who','us','intergrowth']){
        const app=Object.assign(Object.create(WorkspaceApp.prototype),{translations,prefs:{language,growthProfile:profile}});
        const draft=app.emptyDraft(profile);
        for(const mode of profile==='intergrowth'?['days','dates','pma']:['days','dates','months','totalMonths']){
            const current={...draft,ageMode:mode},before=JSON.stringify(current),html=app.formHTML('single',current),batch=app.formHTML('batch',current,true);
            assert.ok(html.includes('entry-flow-grid'));assert.ok(!html.includes('entry-group-title'));
            assert.equal(batch.replaceAll('batch-','single-').replaceAll('data-prefix="batch"','data-prefix="single"'),html);
            assert.ok(html.includes('data-info="growthProfileVisitHelp"'));assert.ok(html.includes('form-section-brief'));assert.ok(html.includes('data-info="'+(profile==='intergrowth'?'intergrowthNoScreening':'clinicalHelp')+'"'));
            if(profile!=='intergrowth')assert.ok(html.includes('data-info="additionalMeasureHelp"'));
            const fields=v=>[...v.matchAll(/ name="([^"]+)"/g)].map(m=>m[1]).sort();assert.deepEqual(fields(html),fields(batch));
            assert.ok(html.includes('data-age="'+mode+'" '));assert.equal(JSON.stringify(current),before);
            assert.ok(html.includes('max="19"'));assert.ok(html.includes('max="11"'));assert.ok(html.includes('max="'+(profile==='intergrowth'?448:profile==='us'?7304:6970)+'"'));
        }
    }
});


test('section help routes to the existing information popup for every screening context',()=>{
    const app=Object.assign(Object.create(WorkspaceApp.prototype),{openInfo(key,opener){this.seen=[key,opener];}});
    for(const key of ['growthProfileVisitHelp','clinicalHelp','pcimaHelp','pcima2025Help','intergrowthNoScreening','additionalMeasureHelp','intergrowthUnsupportedMeasures','muacHelp','pcimaMuacHelp','pcima2025MuacHelp']){app.showInfo(key,'demo');assert.deepEqual(app.seen,[key,'demo']);}
});


test('individual age and unit selectors share their input field and preserve native choices',()=>{
    const translations=data('interface-translations.json');
    for(const language of ['fr','en','ar']){
        const app=Object.assign(Object.create(WorkspaceApp.prototype),{translations,prefs:{language,growthProfile:'who'}});
        const draft=app.emptyDraft(),html=app.formHTML('single',draft),batch=app.formHTML('batch',draft,true);
        assert.equal((html.match(/ data-title-choice/g)||[]).length,3);
        assert.ok(html.includes('class="field title-age" data-field="ageMode"'));
        assert.equal((html.match(/class="field title-measurement"/g)||[]).length,2);
        assert.equal((batch.match(/ data-title-choice/g)||[]).length,3);
        assert.ok(html.includes('class="entry-primary-row"'));assert.ok(html.includes('class="entry-measure-row"'));
        assert.ok(html.includes('placeholder="'+app.t('ageYears')+'"'));assert.ok(html.includes('placeholder="'+app.t('uiMonthsShort')+'"'));assert.ok(batch.includes('class="entry-primary-row"'));
        assert.equal(app.choiceDisplay({dataset:{choicePrefix:app.t('weightMeasure')},selectedOptions:[{textContent:'kg'}]}),app.t('weightMeasure')+' (kg)');
        assert.equal(app.choiceDisplay({dataset:{choiceBirthLabel:app.t('birthDate')},value:'dates',selectedOptions:[{textContent:app.t('dates')}]}),app.t('birthDate'));
    }
});


test('shared entry presentation preserves every field, screening help and correction dialog',()=>{
    const translations=data('interface-translations.json');
    for(const language of ['fr','en','ar'])for(const profile of ['who','us','intergrowth']){
        const app=Object.assign(Object.create(WorkspaceApp.prototype),{translations,prefs:{language,growthProfile:profile}});
        for(const careProtocol of profile==='who'?['','niger2023','niger2025']:['']){
            const draft={...app.emptyDraft(profile),careProtocol,name:'FICTIF',caseId:'DEMO',weight:'9.2',weightUnit:'kg',height:'78.5',heightUnit:'cm',muac:'122',tricepsSkinfold:'7.5'};
            for(const ageMode of profile==='intergrowth'?['days','dates','pma']:['days','totalMonths','months','dates']){
                const current={...draft,ageMode},before=JSON.stringify(current);
                const individual=app.formHTML('single',current),batch=app.formHTML('batch',current,true),correction=app.formHTML('correction',current);
                assert.equal(batch.replaceAll('batch-','single-').replaceAll('data-prefix="batch"','data-prefix="single"'),individual);
                assert.equal(JSON.stringify(current),before);
                assert.ok(!correction.includes('data-title-choice'));assert.ok(correction.includes('entry-group-title'));
                assert.deepEqual([...batch.matchAll(/ name="([^"]+)"/g)].map(m=>m[1]).sort(),[...correction.matchAll(/ name="([^"]+)"/g)].map(m=>m[1]).sort());
            }
        }
    }
});

test('compact individual screening merges only matching MUAC criteria and exposes complete help in FR EN AR',()=>{
    const translations=data('interface-translations.json');
    const entry=engine.calculate(input({growthProfile:'who',careProtocol:'niger2025',ageYears:2,weight:8000,height:84,muac:112}));
    const before=JSON.stringify(entry);
    const normal=engine.calculate(input({growthProfile:'who',careProtocol:'niger2025',muac:150}));
    const unknown=engine.calculate(input({growthProfile:'who',careProtocol:'niger2025',muac:''}));
    for(const language of ['fr','en','ar']){
        const ui=Object.assign(Object.create(WorkspaceApp.prototype),{translations,prefs:{language,theme:'light',growthProfile:'who'}});
        const html=ui.nutritionHTML(entry.child,entry.result,true);
        assert.ok(html.includes('data-info="pcima2025Help"'));assert.ok(html.includes('clinical-method-note summary-print-help'));
        assert.ok(html.includes(ui.esc(ui.t('pcima2025Help'))));
        assert.ok(html.includes(ui.esc(ui.t('criterionMuacSevere'))+' ('+ui.esc(ui.number(112,1))+' mm)'));
        assert.ok(!html.includes(ui.esc(ui.t('muacSevere'))));
        assert.ok(ui.nutritionHTML(normal.child,normal.result,true).includes(ui.esc(ui.t('muacNotLow'))));
        assert.ok(ui.nutritionHTML(unknown.child,unknown.result,true).includes(ui.esc(ui.t('muacMissing'))));
        assert.ok(ui.nutritionHTML(entry.child,entry.result).includes(ui.esc(ui.t('muacSevere'))));
        const additional=ui.additionalResultsHTML(entry.result,true,false);
        assert.ok(additional.includes('data-info="additionalResultHelp"'));
        assert.ok(additional.includes(ui.esc(ui.t('additionalResultHelp'))));
        assert.ok(additional.includes('summary-print-help'));
    }
    assert.equal(JSON.stringify(entry),before);
});

test('lot counters belong only to the list panel and do not consume entry, quality or statistics space',()=>{
 const translations=data('interface-translations.json'),entry=engine.calculate(input());
 for(const language of ['fr','en','ar']){
  const app=Object.assign(Object.create(WorkspaceApp.prototype),{translations,prefs:{language,theme:'light',growthProfile:'who'},engine});
  app.state={...app.emptyWorkspace(),mode:'batch',batch:[entry]};
  for(const pane of ['entry','results','quality','statistics']){
   app.batchPane=pane;const html=app.batchHTML(),start=html.indexOf('id="batch-view-results"'),end=html.indexOf('id="batch-view-quality"'),overview=html.indexOf('class="batch-kpis"');
   assert.ok(start>=0&&overview>start&&overview<end);
   assert.equal((html.match(/class="batch-kpi"/g)||[]).length,7);
   assert.ok(html.indexOf('class="workspace-view-nav"')<html.indexOf('id="measure-card"'));
  }
 }
});

test('batch contextual help and list filters preserve data and distinct reference summaries',()=>{
 const translations=data('interface-translations.json'),entry=engine.calculate(input());
 for(const language of ['fr','en','ar']){
  const app=Object.assign(Object.create(WorkspaceApp.prototype),{translations,prefs:{language,theme:'light',growthProfile:'who'},engine});
  app.state={...app.emptyWorkspace(),mode:'batch',batch:[{child:entry.child,result:null}]};app.batchPane='results';
  const html=app.batchHTML();
  assert.ok(html.indexOf('batch-header-filters')<html.indexOf('class="toolbar compact-toolbar batch-actions"'));
  assert.ok(html.includes('class="batch-record-list"'));assert.ok(html.includes(app.esc(app.t('notCalculated'))));
  assert.ok(!app.batchBrowserHTML().includes('batch-record-toolbar'));
  assert.ok(!app.batchBrowserHTML().includes('batch-record-results'));
  assert.ok(html.includes('data-action="batch-kpi-filter"'));
  assert.ok(!html.includes('id="batch-filter"'));assert.ok(!html.includes('data-value="quality"'));assert.ok(html.includes('data-value="pending"'));
  assert.ok(html.includes('data-info="qualityHelp"'));
  assert.ok(html.includes('data-info="qualityExportHelp"'));assert.ok(html.includes('data-info="analysisPreparationHelp"'));
  assert.ok(html.includes('data-info="lotHelpWho"'));assert.ok(html.includes('class="lot-summary-reference"'));
  assert.ok(app.t('qualityExportHelp')!=='qualityExportHelp');
  assert.equal(app.state.batch[0].result,null);
 }
});

test('lot section headers carry exports, complementary help and compact score ranges, without changing results',()=>{
 const translations=data('interface-translations.json'),entry=engine.calculate(input({headCircumference:48,muac:145,tricepsSkinfold:9,subscapularSkinfold:7}));
 for(const language of ['fr','en','ar']){
  const app=Object.assign(Object.create(WorkspaceApp.prototype),{translations,prefs:{language,theme:'light',growthProfile:'who'},engine});
  app.state={...app.emptyWorkspace(),mode:'batch',batch:[entry],paste:'name,weight'};app.batchPane='statistics';
  const before=JSON.stringify(app.state),html=app.batchHTML();
  assert.ok(/<summary><span class="lot-heading-layout">[^]*?class="toolbar compact-toolbar lot-heading-actions"[^]*?<\/summary>/.test(html));
  assert.ok(html.includes('class="lot-score-range"'));assert.ok(html.includes(app.esc(app.t('lotMeanShort'))));
  assert.ok(html.includes('lot-indicator-help-'));assert.ok(html.includes('class="quality-heading-title"'));
  assert.ok(html.indexOf('id="csv-parse-button"')<html.indexOf('id="csv-tools-body"'));
  assert.equal((html.match(/id="csv-parse-button"/g)||[]).length,1);
  assert.equal(JSON.stringify(app.state),before);
 }
});

test('individual desktop opens optional sections by default without changing batch or mobile visibility',t=>{
 const old=global.matchMedia;t.after(()=>{if(old===undefined)delete global.matchMedia;else global.matchMedia=old;});
 const app=Object.assign(Object.create(WorkspaceApp.prototype),{prefs:{language:'fr',growthProfile:'who'},translations:data('interface-translations.json')});
 const draft=app.emptyDraft('who'),before=JSON.stringify(draft);
 global.matchMedia=q=>({matches:q==='(min-width: 681px)'});
 const single=app.formHTML('single',draft),batch=app.formHTML('batch',draft,true);
 for(const key of ['clinical-fields','additional-fields']){
  assert.ok(single.includes('class="'+key+'" open'));
  assert.ok(batch.includes('class="'+key+'"'));
 }
 global.matchMedia=()=>({matches:false});
 const mobile=app.formHTML('single',draft);
 for(const key of ['clinical-fields','additional-fields'])assert.ok(mobile.includes('class="'+key+'"'));
 assert.equal(JSON.stringify(draft),before);
});
