'use strict';
// Publication needs a recorded rights decision. A technical success is not that decision.
const fs=require('node:fs'),path=require('node:path');
const {preparePublic}=require('./prepare-public.cjs');
const {auditLicenses}=require('./audit-licenses.cjs');
function build({directory=path.resolve(__dirname,'../../dist'),requireRights=true}={}){
    if(requireRights&&!auditLicenses().licenseDistributionReady)throw new Error('Publication suspended: complete GPL notices and corresponding sources before deployment. See docs/references/DISTRIBUTION_GPL.md');
    if(fs.existsSync(directory))throw new Error('Output already exists; nothing overwritten');
    const result=preparePublic();
    fs.cpSync(result.output,directory,{recursive:true,errorOnExist:true,force:false});
    return {...result,output:directory,published:false};
}
if(require.main===module){try{
    // Preview builds may regenerate corresponding sources and integrity pins in the
    // isolated checkout. Production still requires reviewed, committed release bytes.
    if(process.env.VERCEL==='1'&&process.env.VERCEL_ENV==='preview'&&['fix/settings-ui-20261125','fix/ui-finishing-20261125'].includes(process.env.VERCEL_GIT_COMMIT_REF)){
        const {execFileSync}=require('node:child_process');
        execFileSync(process.execPath,[path.join(__dirname,'build-release.cjs')],{stdio:'inherit'});
        execFileSync(process.execPath,[path.join(__dirname,'test-public.cjs')],{stdio:'inherit'});
        execFileSync(process.execPath,[path.join(__dirname,'../verification/verify.cjs')],{stdio:'inherit'});
    }
    console.log(JSON.stringify(build(),null,2));
}catch(e){console.error(e.message);process.exitCode=1;}}
module.exports={build};
